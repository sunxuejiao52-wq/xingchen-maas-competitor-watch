window.__XINGCHEN_COMPETITOR_DATA__ = {
  "updatedAt": "2026-07-15 14:29:54",
  "snapshotDate": "2026-07-14",
  "note": "自动刷新已运行：2026-07-15 14:29:54（北京时间），本次总结 2026-07-14 的竞品动态。日期明确动态 0 条，自动展示平台/高相关新闻线索 16 条。",
  "sources": {
    "baiduModel": {
      "note": "百度千帆模型更新记录 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "百度千帆模型更新记录",
      "vendor": "百度千帆",
      "url": "https://cloud.baidu.com/doc/qianfan/s/Kmh4stnjp",
      "type": "official"
    },
    "baiduCodingPlan": {
      "note": "百度千帆开发者套餐公告 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "百度千帆开发者套餐公告",
      "vendor": "百度千帆",
      "url": "https://cloud.baidu.com/doc/qianfan/s/Emqsyd7yj",
      "type": "official"
    },
    "aliyunModels": {
      "note": "阿里云百炼模型大全 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "阿里云百炼模型大全",
      "vendor": "阿里百炼",
      "url": "https://help.aliyun.com/zh/model-studio/models",
      "type": "official"
    },
    "siliconRelease": {
      "note": "SiliconFlow 更新公告 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "SiliconFlow 更新公告",
      "vendor": "硅基流动",
      "url": "https://docs.siliconflow.cn/cn/release-notes/overview",
      "type": "official"
    },
    "tencentTione": {
      "note": "腾讯云 TI-ONE 文档 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "腾讯云 TI-ONE 文档",
      "vendor": "腾讯云 TI",
      "url": "https://cloud.tencent.com/document/product/851",
      "type": "official"
    },
    "huaweiModelArts": {
      "note": "华为云 ModelArts 文档 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "华为云 ModelArts 文档",
      "vendor": "华为 MaaS",
      "url": "https://support.huaweicloud.com/modelarts/index.html",
      "type": "official"
    },
    "ftChinaModelCost": {
      "title": "Financial Times：中国模型被企业用于降低 AI 成本",
      "vendor": "Financial Times",
      "url": "https://www.ft.com/content/9c8ff45b-7c20-4c2e-93c9-c52339ffdcee",
      "type": "media",
      "note": "媒体报道企业采用 DeepSeek、Z.ai、Moonshot 等中国模型，主要看重成本、开放权重和可自托管能力。"
    },
    "ftVolcanoCloud": {
      "title": "Financial Times：ByteDance 用 AI 云挑战阿里等云厂商",
      "vendor": "Financial Times",
      "url": "https://www.ft.com/content/3732a646-da35-4437-bfde-7f9efc2725ff",
      "type": "media",
      "note": "报道火山引擎借 AI 平台、模型和算力基础设施切入云市场，重点对标阿里、腾讯、华为。"
    },
    "techradarByteDanceChip": {
      "title": "TechRadar：ByteDance 推进 AI 加速芯片",
      "vendor": "TechRadar",
      "url": "https://www.techradar.com/pro/chinese-firm-that-created-tiktok-now-wants-to-build-an-ai-accelerator-to-rival-nvidia-within-months",
      "type": "media",
      "note": "报道 ByteDance 因豆包和 Seedance 等 AI 负载增长，推进自研 AI 加速芯片与基础设施自主化。"
    },
    "barronsChinaAiStocks": {
      "title": "Barron's：中国 AI 股票热度转向阿里、百度等",
      "vendor": "Barron's",
      "url": "https://www.barrons.com/articles/alibaba-stock-price-ai-rally-china-fa4e07ee",
      "type": "media",
      "note": "报道投资者关注中国大模型公司的价格优势和 AI 增长预期，涉及阿里、百度等公司。"
    },
    "barronsZhipuDeepSeek": {
      "title": "Barron's：智谱、DeepSeek 成为中国 AI 投资焦点",
      "vendor": "Barron's",
      "url": "https://www.barrons.com/articles/china-zhipu-ai-deepseek-spending-ed7a2f19",
      "type": "media",
      "note": "报道智谱 GLM、DeepSeek 的成本优势、融资和模型表现，体现中国模型生态热度。"
    },
    "ftBaiduMultimodal": {
      "title": "Financial Times：百度强调多模态模型和千帆生态",
      "vendor": "Financial Times",
      "url": "https://www.ft.com/content/c462fbd1-1672-4d8f-bd91-c3aa185d2418",
      "type": "media",
      "note": "报道百度在开发者大会推出 ERNIE 4.5 Turbo、X1 Turbo 等多模态模型，并将 DeepSeek 接入千帆企业平台。"
    },
    "wechatVolcArkSearch": {
      "title": "公众号检索：火山方舟 / 火山引擎",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E7%81%AB%E5%B1%B1%E6%96%B9%E8%88%9F%20%E7%81%AB%E5%B1%B1%E5%BC%95%E6%93%8E",
      "type": "wechat",
      "note": "公众号检索：火山方舟 / 火山引擎 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "wechatQianfanSearch": {
      "title": "公众号检索：百度千帆 / 文心千帆",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E7%99%BE%E5%BA%A6%E5%8D%83%E5%B8%86%20%E6%96%87%E5%BF%83%E5%8D%83%E5%B8%86",
      "type": "wechat",
      "note": "公众号检索：百度千帆 / 文心千帆 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "wechatBailianSearch": {
      "title": "公众号检索：阿里百炼 / 通义千问",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E9%98%BF%E9%87%8C%E7%99%BE%E7%82%BC%20%E9%80%9A%E4%B9%89%E5%8D%83%E9%97%AE",
      "type": "wechat",
      "note": "公众号检索：阿里百炼 / 通义千问 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "wechatSiliconSearch": {
      "title": "公众号检索：硅基流动 / SiliconFlow",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E7%A1%85%E5%9F%BA%E6%B5%81%E5%8A%A8%20SiliconFlow",
      "type": "wechat",
      "note": "公众号检索：硅基流动 / SiliconFlow 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "volcArkApi": {
      "title": "火山方舟接口文档",
      "vendor": "火山方舟",
      "url": "https://www.volcengine.com/docs/82379/1494384?lang=zh",
      "type": "official",
      "note": "火山方舟接口文档 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "baiduPlatform": {
      "title": "百度千帆更新动态",
      "vendor": "百度千帆",
      "url": "https://cloud.baidu.com/doc/qianfan/s/Mmh8l4qwj",
      "type": "official",
      "note": "百度千帆更新动态 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "aliyunMcp": {
      "title": "阿里云百炼工具接入文档",
      "vendor": "阿里百炼",
      "url": "https://help.aliyun.com/zh/model-studio/mcp-introduction",
      "type": "official",
      "note": "阿里云百炼工具接入文档 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "aliyunCodingPlan": {
      "title": "阿里云百炼开发者套餐",
      "vendor": "阿里百炼",
      "url": "https://help.aliyun.com/zh/model-studio/coding-plan",
      "type": "official",
      "note": "阿里云百炼开发者套餐 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "zhipuExternal": {
      "title": "智谱 BigModel 模型广场",
      "vendor": "智谱 AI",
      "url": "https://bigmodel.cn/console/modelcenter/square",
      "type": "official",
      "note": "智谱 BigModel 模型广场 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "wechatZhipuSearch": {
      "title": "公众号检索：智谱 AI / GLM",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E6%99%BA%E8%B0%B1AI%20GLM%20BigModel",
      "type": "wechat",
      "note": "公众号检索：智谱 AI / GLM 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "mediaBaiduQianfanSearch": {
      "title": "新闻检索：百度千帆",
      "vendor": "新闻检索",
      "url": "https://www.baidu.com/s?wd=%E7%99%BE%E5%BA%A6%E5%8D%83%E5%B8%86%20%E5%A4%A7%E6%A8%A1%E5%9E%8B%20%E6%9B%B4%E6%96%B0",
      "type": "media",
      "note": "新闻检索：百度千帆 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "mediaAliyunBailianSearch": {
      "title": "新闻检索：阿里百炼",
      "vendor": "新闻检索",
      "url": "https://www.baidu.com/s?wd=%E9%98%BF%E9%87%8C%E7%99%BE%E7%82%BC%20%E9%80%9A%E4%B9%89%20%E5%A4%A7%E6%A8%A1%E5%9E%8B",
      "type": "media",
      "note": "新闻检索：阿里百炼 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "mediaVolcArkSearch": {
      "title": "新闻检索：火山方舟",
      "vendor": "新闻检索",
      "url": "https://www.baidu.com/s?wd=%E7%81%AB%E5%B1%B1%E6%96%B9%E8%88%9F%20%E8%B1%86%E5%8C%85%20%E5%A4%A7%E6%A8%A1%E5%9E%8B",
      "type": "media",
      "note": "新闻检索：火山方舟 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    },
    "mediaZhipuSearch": {
      "title": "新闻检索：智谱 AI",
      "vendor": "新闻检索",
      "url": "https://www.baidu.com/s?wd=%E6%99%BA%E8%B0%B1AI%20GLM%20BigModel%20%E5%A4%A7%E6%A8%A1%E5%9E%8B",
      "type": "media",
      "note": "新闻检索：智谱 AI 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。"
    }
  },
  "competitors": [
    {
      "id": "baidu",
      "lastSeen": "2026-07-09",
      "thesis": "动作最密集：新模型、模型退役、智能体、工具广场、AI 搜索和开发者套餐一起推进。",
      "watchNext": "Token Plan 迁移、模型退役节奏、深度研究助手收费、百度搜索工具、AI 搜索控制台、视频与 PPT 工具。"
    }
  ],
  "events": [
    {
      "id": "baidu-20260709-model-retire",
      "competitor": "baidu",
      "date": "2026-07-09",
      "title": "Kimi-K2.5、MiniMax-M2.5 在千帆进入退役记录",
      "summary": "百度千帆模型更新记录显示，2026 年 7 月 9 日 Kimi-K2.5 和 MiniMax-M2.5 退役，并指向模型版本升级及退役机制。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台开始更主动管理模型生命周期，星辰也需要清楚提示模型上下线、替代模型和迁移影响。"
    }
  ],
  "news": [
    {
      "id": "candidate-volc-ark-docs-2026-07-14",
      "competitor": "volc",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "火山方舟接口文档 公开更新内容",
      "summary": "页面里出现了“火山方舟”相关内容。 原文片段：文档中心 简体 文档 控制台 登录 注册 火山方舟 文档指南 订阅 [Agent/Coding Plan] API参考 资源 火山方舟 火山方舟 API参考 请输入 准备工作 获取 API Key 并配置 安装及升级 SDK Base URL及鉴权 对话(Chat) API 对话(Chat) API Responses API 创建模型响应 查询模型响应 获…",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "model",
        "agent",
        "multimodal",
        "platform"
      ],
      "priority": "high",
      "source": "volcArkApi",
      "keyword": "火山方舟",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-baidu-qianfan-model-2026-07-14",
      "competitor": "baidu",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "百度千帆模型更新记录 公开更新内容",
      "summary": "页面里出现了“千帆”相关内容。 原文片段：模型更新记录 - 百度千帆·大模型服务及Agent开发平台 百度智能云 最新活动 产品 解决方案 企业服务 云市场 合作与生态 开发者 服务与支持 了解智能云 备案 文档 管理控制台 文档中心 搜索本产品文档关键词 立即试用 模型更新记录 百度千帆·大模型服务及Agent开发平台 平台介绍 平台简介 更新动态 产品公告 模型服务 模型更新记录 平台更新记录 …",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "keyword": "千帆",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-baidu-qianfan-platform-2026-07-14",
      "competitor": "baidu",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "百度千帆更新动态 公开更新内容",
      "summary": "页面里出现了“智能体”相关内容。 原文片段：…工作流Agent：“金牌销售”车险续保Agent 工作流Agent：如何使用全局跳转节点搭建飞行客服小助手 工作流Agent：机票订单处理助手 工作流大模型节点高级配置使用案例 多智能体协同Agent最佳实践 用“多智能体协同Agent”一分钟搭建专属研究Agent，帮企业做深度研究 自定义工具最佳实践 工作流组件： API的增删查 工作流组件：如何用知识…",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "agent",
        "tools",
        "business"
      ],
      "priority": "high",
      "source": "baiduPlatform",
      "keyword": "智能体",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-baidu-qianfan-coding-2026-07-14",
      "competitor": "baidu",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "百度千帆开发者套餐公告 公开更新内容",
      "summary": "页面里出现了“Coding Plan”相关内容。 原文片段：Coding Plan 产品升级公告 - 百度千帆·大模型服务及Agent开发平台 百度智能云 最新活动 产品 解决方案 企业服务 云市场 合作与生态 开发者 服务与支持 了解智能云 备案 文档 管理控制台 文档中心 搜索本产品文档关键词 立即试用 Coding Plan 产品升级公告 百度千帆·大模型服务及Agent开发平台 平台介绍 平台简介 更新动态 …",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "coding",
        "business"
      ],
      "priority": "high",
      "source": "baiduCodingPlan",
      "keyword": "Coding Plan",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-aliyun-bailian-models-2026-07-14",
      "competitor": "aliyun",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "阿里云百炼模型大全 公开更新内容",
      "summary": "页面里出现了“百炼”相关内容。 原文片段：模型大全功能规格与计费-大模型服务平台百炼-阿里云-大模型服务平台百炼(Model Studio)-阿里云帮助中心 大模型 产品 解决方案 权益 定价 云市场 伙伴 服务 了解阿里云 查看 \"\" 全部搜索结果 AI 助理 文档 备案 控制台 官方文档 用户指南（模型） 用户指南（应用） API参考（模型） API参考（应用） 首页 选择模型 更新时间： 复制…",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "model",
        "multimodal"
      ],
      "priority": "high",
      "source": "aliyunModels",
      "keyword": "百炼",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-aliyun-bailian-mcp-2026-07-14",
      "competitor": "aliyun",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "阿里云百炼工具接入文档 公开更新内容",
      "summary": "页面里出现了“MCP”相关内容。 原文片段：模型上下文协议（MCP）-大模型服务平台百炼(Model Studio)-阿里云帮助中心 大模型 产品 解决方案 权益 定价 云市场 伙伴 服务 了解阿里云 查看 \"\" 全部搜索结果 AI 助理 文档 备案 控制台 官方文档 用户指南（模型） 用户指南（应用） API参考（模型） API参考（应用） 首页 模型上下文协议（MCP） 更新时间： 复制 MD 格…",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "agent",
        "tools"
      ],
      "priority": "high",
      "source": "aliyunMcp",
      "keyword": "MCP",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-aliyun-bailian-coding-2026-07-14",
      "competitor": "aliyun",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "阿里云百炼开发者套餐 公开更新内容",
      "summary": "页面里出现了“Coding Plan”相关内容。 原文片段：Coding Plan-大模型服务平台百炼(Model Studio)-阿里云帮助中心 大模型 产品 解决方案 权益 定价 云市场 伙伴 服务 了解阿里云 查看 \"\" 全部搜索结果 AI 助理 文档 备案 控制台 官方文档 用户指南（模型） 用户指南（应用） API参考（模型） API参考（应用） 首页 Coding Plan概述 更新时间： 复制 MD 格…",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "coding",
        "business"
      ],
      "priority": "medium",
      "source": "aliyunCodingPlan",
      "keyword": "Coding Plan",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-siliconflow-release-2026-07-14",
      "competitor": "silicon",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "SiliconFlow 更新公告 公开更新内容",
      "summary": "页面里出现了“SiliconFlow”相关内容。 原文片段：更新公告 - SiliconFlow Documentation Index Fetch the complete documentation index at: /llms.txt Use this file to discover all available pages before exploring further. Skip to main con…",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "model",
        "business",
        "governance"
      ],
      "priority": "high",
      "source": "siliconRelease",
      "keyword": "SiliconFlow",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-tencent-tione-docs-2026-07-14",
      "competitor": "tencent",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "腾讯云 TI-ONE 文档 公开更新内容",
      "summary": "页面里出现了“TI-ONE”相关内容。 原文片段：腾讯云大模型训推平台TI-ONE简介_腾讯云大模型训推平台TI-ONE购买指南_腾讯云大模型训推平台TI-ONE操作指南-腾讯云 腾讯云 最新活动 大模型 产品 解决方案 定价 企业中心 云市场 开发者 客户支持 合作与生态 了解腾讯云 搜索 腾讯云大模型训推平台TI-ONE 文档中心 入门中心 API 中心 SDK 中心 文档活动 我的反馈 文档反馈官招募…",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "platform",
        "model"
      ],
      "priority": "medium",
      "source": "tencentTione",
      "keyword": "TI-ONE",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-huawei-modelarts-docs-2026-07-14",
      "competitor": "huawei",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "华为云 ModelArts 文档 公开更新内容",
      "summary": "页面里出现了“ModelArts”相关内容。 原文片段：成长地图_魔坊（ModelArts）模型训推平台-华为云 检测到您已登录华为云国际站账号，为了您更好的体验，建议您访问国际站服务网站 https://www.huaweicloud.com/intl/zh-cn 不再显示此消息 中国站 中国站 简体中文 International English Bahasa Indonesia Español Portug…",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "platform",
        "agent"
      ],
      "priority": "medium",
      "source": "huaweiModelArts",
      "keyword": "ModelArts",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-zhipu-bigmodel-console-2026-07-14",
      "competitor": "zhipu",
      "date": "2026-07-14",
      "kind": "平台更新监测",
      "title": "智谱 BigModel 模型广场 公开更新内容",
      "summary": "页面里出现了“智谱”相关内容。 原文片段：智谱AI开放平台",
      "takeaway": "简单说，这是该平台公开文档或公告页中的相关更新内容，系统已纳入当天平台动态观察。",
      "categories": [
        "model",
        "agent"
      ],
      "priority": "medium",
      "source": "zhipuExternal",
      "keyword": "智谱",
      "relevanceScore": 12,
      "autoCandidate": true
    },
    {
      "id": "candidate-wechat-volc-ark-2026-07-14",
      "competitor": "volc",
      "date": "2026-07-14",
      "kind": "公众号监测",
      "title": "公众号检索：火山方舟 / 火山引擎 公众号内容信号",
      "summary": "页面里出现了“火山方舟”相关内容。 原文片段：火山方舟 火山引擎的相关微信公众号文章 – 搜狗微信搜索 无障碍 登录 资讯 网页 微信 知乎 图片 视频 医疗 汉语 翻译 问问 百科 更多>> 以下内容来自微信公众平台 豆包大模型家族发布、 火山方舟 升级, 火山引擎 如何打造全栈AI技术服务? 火山引擎 重磅发布了豆包大模型家族和 火山方舟 2.0 等一系列创新产品,并且宣布豆包主力模型在…",
      "takeaway": "简单说，这是公众号检索中与竞品高度相关的内容信号，适合用来观察宣传重点和市场动作。",
      "categories": [
        "model",
        "agent",
        "business"
      ],
      "priority": "medium",
      "source": "wechatVolcArkSearch",
      "keyword": "火山方舟",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-wechat-baidu-qianfan-2026-07-14",
      "competitor": "baidu",
      "date": "2026-07-14",
      "kind": "公众号监测",
      "title": "公众号检索：百度千帆 / 文心千帆 公众号内容信号",
      "summary": "页面里出现了“百度千帆”相关内容。 原文片段：百度千帆 文心千帆的相关微信公众号文章 – 搜狗微信搜索 无障碍 登录 资讯 网页 微信 知乎 图片 视频 医疗 汉语 翻译 问问 百科 更多>> 以下内容来自微信公众平台 百度 文心千帆 大模型平台的试用体验 百度 文心千帆 大模型里也能通过类 Stable-Diffusion 模型,完成简… 百度千帆 大模型已经提供了基于大型数据集预训练…",
      "takeaway": "简单说，这是公众号检索中与竞品高度相关的内容信号，适合用来观察宣传重点和市场动作。",
      "categories": [
        "model",
        "agent",
        "business"
      ],
      "priority": "medium",
      "source": "wechatQianfanSearch",
      "keyword": "百度千帆",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-wechat-aliyun-bailian-2026-07-14",
      "competitor": "aliyun",
      "date": "2026-07-14",
      "kind": "公众号监测",
      "title": "公众号检索：阿里百炼 / 通义千问 公众号内容信号",
      "summary": "页面里出现了“阿里百炼”相关内容。 原文片段：阿里百炼 通义千问的相关微信公众号文章 – 搜狗微信搜索 无障碍 登录 资讯 网页 微信 知乎 图片 视频 医疗 汉语 翻译 问问 百科 更多>> 以下内容来自微信公众平台 阿里 整合 通义 、 千问 、钉钉和淘天旗下的AI团队,全面学习Google MaaS业务线(含 阿里 云 百炼 ,负责模型服务与企业交付)下游: 千问 事业部(C端)、悟空…",
      "takeaway": "简单说，这是公众号检索中与竞品高度相关的内容信号，适合用来观察宣传重点和市场动作。",
      "categories": [
        "model",
        "agent",
        "multimodal"
      ],
      "priority": "medium",
      "source": "wechatBailianSearch",
      "keyword": "阿里百炼",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-wechat-siliconflow-2026-07-14",
      "competitor": "silicon",
      "date": "2026-07-14",
      "kind": "公众号监测",
      "title": "公众号检索：硅基流动 / SiliconFlow 公众号内容信号",
      "summary": "页面里出现了“硅基流动”相关内容。 原文片段：硅基流动 SiliconFlow的相关微信公众号文章 – 搜狗微信搜索 无障碍 登录 资讯 网页 微信 知乎 图片 视频 医疗 汉语 翻译 问问 百科 更多>> 以下内容来自微信公众平台 硅基流动 省钱指南:7个策略把API成本砍掉90% 硅基流动 ( SiliconFlow )作为国内最大的开源模型聚合平台,聚合了200+模型,覆盖从DeepS…",
      "takeaway": "简单说，这是公众号检索中与竞品高度相关的内容信号，适合用来观察宣传重点和市场动作。",
      "categories": [
        "model",
        "business"
      ],
      "priority": "medium",
      "source": "wechatSiliconSearch",
      "keyword": "硅基流动",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-wechat-zhipu-ai-2026-07-14",
      "competitor": "zhipu",
      "date": "2026-07-14",
      "kind": "公众号监测",
      "title": "公众号检索：智谱 AI / GLM 公众号内容信号",
      "summary": "页面里出现了“智谱”相关内容。 原文片段：智谱AI GLM BigModel的相关微信公众号文章 – 搜狗微信搜索 无障碍 登录 资讯 网页 微信 知乎 图片 视频 医疗 汉语 翻译 问问 百科 更多>> 以下内容来自微信公众平台 智谱AI GLM -4 模型 开放API 正式上线 //open. bigmodel .cn/dev/api# glm -4),目前新用户注册登录还有50…",
      "takeaway": "简单说，这是公众号检索中与竞品高度相关的内容信号，适合用来观察宣传重点和市场动作。",
      "categories": [
        "model",
        "agent"
      ],
      "priority": "medium",
      "source": "wechatZhipuSearch",
      "keyword": "智谱",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "news-media-20260713-china-model-cost",
      "competitor": "zhipu",
      "date": "2026-07-13",
      "kind": "媒体报道",
      "title": "FT：海外企业开始用中国模型降低 AI 成本",
      "summary": "Financial Times 报道称，部分海外企业采用 DeepSeek、Z.ai、Moonshot 等中国模型，看重低成本、代码能力、开放权重和可自托管。",
      "takeaway": "简单说，MaaS 平台的竞争不只是模型强不强，还包括价格、开放度、部署灵活性和企业可控性。",
      "categories": [
        "model",
        "business",
        "platform"
      ],
      "priority": "high",
      "source": "ftChinaModelCost"
    },
    {
      "id": "news-wechat-monitor-20260713",
      "competitor": "volc",
      "date": "2026-07-13",
      "kind": "公众号监测",
      "title": "新增公众号检索入口：火山方舟、百度千帆、阿里百炼、硅基流动",
      "summary": "已加入微信公众平台检索入口，用来跟踪公众号里的活动宣传、客户案例、行业解读和价格讨论。",
      "takeaway": "简单说，公众号更适合看传播口径和市场热度；功能事实仍以官方公告和产品文档为准。",
      "categories": [
        "platform",
        "business"
      ],
      "priority": "medium",
      "source": "wechatVolcArkSearch"
    },
    {
      "id": "news-wechat-baidu-20260713",
      "competitor": "baidu",
      "date": "2026-07-13",
      "kind": "公众号监测",
      "title": "公众号追踪：百度千帆 / 文心千帆",
      "summary": "新增千帆相关公众号检索入口，后续重点看活动宣传、开发者套餐解读、AI 搜索和智能体案例传播。",
      "takeaway": "简单说，百度的公众号内容适合观察“怎么包装产品”和“主推哪些场景”。",
      "categories": [
        "agent",
        "tools",
        "business"
      ],
      "priority": "medium",
      "source": "wechatQianfanSearch"
    },
    {
      "id": "news-wechat-aliyun-20260713",
      "competitor": "aliyun",
      "date": "2026-07-13",
      "kind": "公众号监测",
      "title": "公众号追踪：阿里百炼 / 通义千问",
      "summary": "新增阿里百炼和通义千问相关公众号检索入口，后续重点看模型上新、开发者工具、客户案例和云产品联动。",
      "takeaway": "简单说，阿里的公众号内容适合观察模型生态和云上应用开发怎么组合传播。",
      "categories": [
        "model",
        "agent",
        "platform"
      ],
      "priority": "medium",
      "source": "wechatBailianSearch"
    },
    {
      "id": "news-wechat-silicon-20260713",
      "competitor": "silicon",
      "date": "2026-07-13",
      "kind": "公众号监测",
      "title": "公众号追踪：硅基流动 / SiliconFlow",
      "summary": "新增硅基流动相关公众号检索入口，后续重点看模型价格、DeepSeek/Qwen/GLM 接入、调用额度和开发者口碑。",
      "takeaway": "简单说，硅基流动的公众号与社区讨论更适合观察低价模型调用是否形成开发者心智。",
      "categories": [
        "model",
        "business"
      ],
      "priority": "medium",
      "source": "wechatSiliconSearch"
    },
    {
      "id": "news-media-20260710-barrons-china-ai",
      "competitor": "aliyun",
      "date": "2026-07-10",
      "kind": "媒体报道",
      "title": "Barron's：市场重新关注中国 AI 公司和云厂商",
      "summary": "Barron's 报道提到，投资者关注阿里、百度等中国 AI 相关公司，核心逻辑是大模型成本优势和 AI 云增长预期。",
      "takeaway": "简单说，资本市场也在把阿里、百度这些 MaaS/云厂商当作中国 AI 基础设施代表来观察。",
      "categories": [
        "business",
        "platform"
      ],
      "priority": "medium",
      "source": "barronsChinaAiStocks"
    },
    {
      "id": "news-media-20260710-zhipu-deepseek",
      "competitor": "zhipu",
      "date": "2026-07-10",
      "kind": "媒体报道",
      "title": "Barron's：智谱和 DeepSeek 成为中国模型竞争焦点",
      "summary": "报道提到智谱 GLM、DeepSeek 的成本优势、融资和模型表现，反映中国模型厂商正在被国际投资者和企业客户关注。",
      "takeaway": "简单说，智谱这类模型公司会继续通过模型能力和价格影响各 MaaS 平台的模型货架。",
      "categories": [
        "model",
        "business"
      ],
      "priority": "medium",
      "source": "barronsZhipuDeepSeek"
    },
    {
      "id": "news-baidu-20260709-model-retire",
      "competitor": "baidu",
      "date": "2026-07-09",
      "kind": "产品公告",
      "title": "百度千帆 7 月模型更新以“退役旧模型”为主",
      "summary": "千帆模型更新记录的 2026 年 7 月条目显示，Kimi-K2.5 与 MiniMax-M2.5 进入退役状态。",
      "takeaway": "简单说，百度不只是上新模型，也在整理旧模型；这会影响企业客户的迁移和稳定性预期。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel"
    },
    {
      "id": "news-media-20260708-bytedance-chip",
      "competitor": "volc",
      "date": "2026-07-08",
      "kind": "媒体报道",
      "title": "TechRadar：ByteDance 推进 AI 加速芯片，支撑豆包和 Seedance 负载",
      "summary": "TechRadar 报道称，ByteDance 因豆包聊天机器人和 Seedance 视频模型等 AI 负载增长，推进 AI 加速芯片和基础设施自主化。",
      "takeaway": "简单说，火山方舟背后的竞争力可能不只在模型和控制台，也在算力成本、芯片和基础设施储备。",
      "categories": [
        "platform",
        "multimodal"
      ],
      "priority": "high",
      "source": "techradarByteDanceChip"
    },
    {
      "id": "news-aliyun-20260706-model-market",
      "competitor": "aliyun",
      "date": "2026-07-06",
      "kind": "产品资料",
      "title": "阿里百炼模型目录继续强化“模型超市”心智",
      "summary": "百炼模型目录展示千问及第三方模型，覆盖文本、图像、视频、3D、音频与语音等多类能力。",
      "takeaway": "简单说，阿里在把模型选型做成一个大货架，用户可以按场景挑模型。",
      "categories": [
        "model",
        "multimodal"
      ],
      "priority": "high",
      "source": "aliyunModels"
    },
    {
      "id": "news-tencent-20260706-tione-platform",
      "competitor": "tencent",
      "date": "2026-07-06",
      "kind": "产品资料",
      "title": "腾讯云 TI-ONE 仍主打训练、评测、部署全流程",
      "summary": "腾讯云 TI-ONE 文档强调从数据接入、模型训练、模型管理到模型服务的全流程支持，并提供 DeepSeek、混元和推理加速教程。",
      "takeaway": "简单说，腾讯更像工程工作台，不是单纯模型货架。",
      "categories": [
        "platform",
        "model"
      ],
      "priority": "medium",
      "source": "tencentTione"
    },
    {
      "id": "news-baidu-20260626-token-plan",
      "competitor": "baidu",
      "date": "2026-06-26",
      "kind": "套餐变化",
      "title": "百度千帆把 Coding Plan 往 Token Plan 迁移",
      "summary": "百度公告称旧 Coding Plan 自 2026 年 6 月 25 日起停止续费，后续通过 Token Plan 提供更灵活的模型选择和使用方式。",
      "takeaway": "简单说，百度希望用户用一套额度消费更多模型，而不是只买单一编程套餐。",
      "categories": [
        "coding",
        "business"
      ],
      "priority": "high",
      "source": "baiduCodingPlan"
    },
    {
      "id": "news-zhipu-20260617-ecosystem",
      "competitor": "zhipu",
      "date": "2026-06-17",
      "kind": "生态信号",
      "title": "GLM-5.2 在千帆、百炼等平台形成可见信号",
      "summary": "本轮仍需补智谱 BigModel 官方更新日志，但 GLM-5.2 已在百度千帆和阿里百炼等平台出现。",
      "takeaway": "简单说，智谱的新模型即使官方口径待补，也已经通过其他 MaaS 平台影响开发者选择。",
      "categories": [
        "model",
        "agent"
      ],
      "priority": "medium",
      "source": "zhipuExternal"
    },
    {
      "id": "news-silicon-20260605-model-switch",
      "competitor": "silicon",
      "date": "2026-06-05",
      "kind": "产品公告",
      "title": "硅基流动公告旧模型下线并自动指向新版本",
      "summary": "SiliconFlow 公告显示，Kimi-K2.5、GLM-5 等模型会下线，部分请求将分别指向 Kimi-K2.6、GLM-5.1。",
      "takeaway": "简单说，硅基流动在帮用户自动换模型，但用户仍要关注价格、效果和兼容性。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "siliconRelease"
    },
    {
      "id": "news-silicon-20260507-realname",
      "competitor": "silicon",
      "date": "2026-05-07",
      "kind": "账号规则",
      "title": "硅基流动要求未实名账户完成认证",
      "summary": "SiliconFlow 公告称，自 2026 年 5 月 15 日起，未完成实名认证的账户将无法使用平台功能。",
      "takeaway": "简单说，低门槛推理平台规模变大后，也开始补合规和账号安全。",
      "categories": [
        "governance"
      ],
      "priority": "medium",
      "source": "siliconRelease"
    },
    {
      "id": "news-aliyun-20260320-coding-plan",
      "competitor": "aliyun",
      "date": "2026-03-20",
      "kind": "套餐变化",
      "title": "阿里百炼 Coding Plan Lite 停止新购",
      "summary": "阿里百炼 Coding Plan 文档显示，Lite 套餐自 2026 年 3 月 20 日起停止新购，后续引导到 Pro 套餐和专属 API Key/Base URL。",
      "takeaway": "简单说，阿里也在调整编程套餐，把开发者使用入口做得更可控。",
      "categories": [
        "coding",
        "business",
        "governance"
      ],
      "priority": "medium",
      "source": "aliyunCodingPlan"
    },
    {
      "id": "news-media-20260213-volcano-ai-cloud",
      "competitor": "volc",
      "date": "2026-02-13",
      "kind": "媒体报道",
      "title": "FT：ByteDance 通过火山引擎加码 AI 云",
      "summary": "Financial Times 报道称，ByteDance 正通过火山引擎和 AI 平台挑战阿里、腾讯、华为等云厂商，并受益于模型、算力和消费级生态。",
      "takeaway": "简单说，火山方舟要按“AI 云平台”来看，不只是豆包模型 API。",
      "categories": [
        "platform",
        "business",
        "agent"
      ],
      "priority": "high",
      "source": "ftVolcanoCloud"
    },
    {
      "id": "news-huawei-20250924-modelarts-maas",
      "competitor": "huawei",
      "date": "2025-09-24",
      "kind": "产品资料",
      "title": "华为 ModelArts 入口关联 MaaS 和 AgentArts",
      "summary": "华为云 ModelArts 成长地图页面显示，热门产品入口包含 ModelArts、MaaS 模型即服务和 AgentArts 智能体平台。",
      "takeaway": "简单说，华为的重点更偏企业训练部署、算力底座和智能体平台组合。",
      "categories": [
        "platform",
        "agent"
      ],
      "priority": "medium",
      "source": "huaweiModelArts"
    },
    {
      "id": "news-media-202504-baidu-multimodal",
      "competitor": "baidu",
      "date": "2025-04-25",
      "kind": "媒体报道",
      "title": "FT：百度用多模态和千帆生态回应 DeepSeek 竞争",
      "summary": "Financial Times 报道称，百度推出 ERNIE 4.5 Turbo、X1 Turbo 等多模态模型，并把 DeepSeek 接入千帆企业平台。",
      "takeaway": "简单说，百度千帆的方向是“自有模型 + 外部热门模型 + 多模态 + 企业平台”一起做。",
      "categories": [
        "model",
        "multimodal",
        "platform"
      ],
      "priority": "medium",
      "source": "ftBaiduMultimodal"
    }
  ],
  "strategies": [],
  "monitorRuns": [
    {
      "targetDate": "2026-07-14",
      "runDateTime": "2026-07-15 14:29:54",
      "sourcesChecked": 20,
      "exactMatches": 0,
      "publishedCandidates": 16,
      "candidates": 16,
      "errors": 0
    },
    {
      "targetDate": "2026-07-15",
      "runDateTime": "2026-07-15 09:26:49",
      "sourcesChecked": 20,
      "exactMatches": 0,
      "candidates": 19,
      "errors": 0
    }
  ]
};
