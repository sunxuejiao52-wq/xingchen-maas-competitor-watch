window.__XINGCHEN_COMPETITOR_DATA__ = {
  "updatedAt": "2026-11-19 07:15:57",
  "snapshotDate": "2026-11-18",
  "note": "自动刷新已运行：2026-11-19 07:15:57（北京时间），本次按“平台自己的官方更新记录”口径总结 2026-11-18 的竞品动态。官方更新记录 0 条，新闻/公众号线索 1 条，官方模型更新 23 条。",
  "sources": {
    "baiduModel": {
      "note": "百度千帆模型更新记录 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "百度千帆模型更新记录",
      "vendor": "百度千帆",
      "url": "https://cloud.baidu.com/doc/qianfan/s/Kmh4stnjp",
      "type": "official",
      "recordType": "official_update_record",
      "competitor": "baidu",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high"
    },
    "baiduCodingPlan": {
      "note": "百度千帆开发者套餐公告 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "百度千帆开发者套餐公告",
      "vendor": "百度千帆",
      "url": "https://cloud.baidu.com/doc/qianfan/s/Emqsyd7yj",
      "type": "official",
      "recordType": "official_update_record",
      "competitor": "baidu",
      "categories": [
        "coding",
        "business"
      ],
      "priority": "high"
    },
    "aliyunModels": {
      "note": "阿里云百炼模型大全 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "阿里云百炼模型大全",
      "vendor": "阿里百炼",
      "url": "https://help.aliyun.com/zh/model-studio/models",
      "type": "official",
      "recordType": "",
      "competitor": "aliyun",
      "categories": [
        "model",
        "multimodal"
      ],
      "priority": "high"
    },
    "siliconRelease": {
      "note": "SiliconFlow 更新公告 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "SiliconFlow 更新公告",
      "vendor": "硅基流动",
      "url": "https://docs.siliconflow.cn/cn/release-notes/overview",
      "type": "official",
      "recordType": "official_update_record",
      "competitor": "silicon",
      "categories": [
        "model",
        "business",
        "governance"
      ],
      "priority": "high"
    },
    "tencentTione": {
      "note": "腾讯云 TI-ONE 文档 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "腾讯云 TI-ONE 文档",
      "vendor": "腾讯云 TI",
      "url": "https://cloud.tencent.com/document/product/851",
      "type": "official",
      "recordType": "",
      "competitor": "tencent",
      "categories": [
        "platform",
        "model"
      ],
      "priority": "medium"
    },
    "huaweiModelArts": {
      "note": "华为云 ModelArts 文档 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "title": "华为云 ModelArts 文档",
      "vendor": "华为 MaaS",
      "url": "https://support.huaweicloud.com/modelarts/index.html",
      "type": "official",
      "recordType": "",
      "competitor": "huawei",
      "categories": [
        "platform",
        "agent"
      ],
      "priority": "medium"
    },
    "ftChinaModelCost": {
      "title": "Financial Times：中国模型被企业用于降低 AI 成本",
      "vendor": "Financial Times",
      "url": "https://www.ft.com/content/9c8ff45b-7c20-4c2e-93c9-c52339ffdcee",
      "type": "media",
      "note": "媒体报道企业采用 DeepSeek、Z.ai、Moonshot 等中国模型，主要看重成本、开放权重和可自托管能力。"
    },
    "ftVolcanoCloud": {
      "title": "Financial Times：ByteDance 用 AI 云挑战阿里等云厂商",
      "vendor": "Financial Times",
      "url": "https://www.ft.com/content/3732a646-da35-4437-bfde-7f9efc2725ff",
      "type": "media",
      "note": "报道火山引擎借 AI 平台、模型和算力基础设施切入云市场，重点对标阿里、腾讯、华为。"
    },
    "techradarByteDanceChip": {
      "title": "TechRadar：ByteDance 推进 AI 加速芯片",
      "vendor": "TechRadar",
      "url": "https://www.techradar.com/pro/chinese-firm-that-created-tiktok-now-wants-to-build-an-ai-accelerator-to-rival-nvidia-within-months",
      "type": "media",
      "note": "报道 ByteDance 因豆包和 Seedance 等 AI 负载增长，推进自研 AI 加速芯片与基础设施自主化。"
    },
    "barronsChinaAiStocks": {
      "title": "Barron's：中国 AI 股票热度转向阿里、百度等",
      "vendor": "Barron's",
      "url": "https://www.barrons.com/articles/alibaba-stock-price-ai-rally-china-fa4e07ee",
      "type": "media",
      "note": "报道投资者关注中国大模型公司的价格优势和 AI 增长预期，涉及阿里、百度等公司。"
    },
    "barronsZhipuDeepSeek": {
      "title": "Barron's：智谱、DeepSeek 成为中国 AI 投资焦点",
      "vendor": "Barron's",
      "url": "https://www.barrons.com/articles/china-zhipu-ai-deepseek-spending-ed7a2f19",
      "type": "media",
      "note": "报道智谱 GLM、DeepSeek 的成本优势、融资和模型表现，体现中国模型生态热度。"
    },
    "ftBaiduMultimodal": {
      "title": "Financial Times：百度强调多模态模型和千帆生态",
      "vendor": "Financial Times",
      "url": "https://www.ft.com/content/c462fbd1-1672-4d8f-bd91-c3aa185d2418",
      "type": "media",
      "note": "报道百度在开发者大会推出 ERNIE 4.5 Turbo、X1 Turbo 等多模态模型，并将 DeepSeek 接入千帆企业平台。"
    },
    "wechatVolcArkSearch": {
      "title": "公众号检索：火山方舟 / 火山引擎",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E7%81%AB%E5%B1%B1%E6%96%B9%E8%88%9F%20%E7%81%AB%E5%B1%B1%E5%BC%95%E6%93%8E",
      "type": "wechat",
      "note": "公众号检索：火山方舟 / 火山引擎 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "volc",
      "categories": [
        "model",
        "agent",
        "business"
      ],
      "priority": "medium"
    },
    "wechatQianfanSearch": {
      "title": "公众号检索：百度千帆 / 文心千帆",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E7%99%BE%E5%BA%A6%E5%8D%83%E5%B8%86%20%E6%96%87%E5%BF%83%E5%8D%83%E5%B8%86",
      "type": "wechat",
      "note": "公众号检索：百度千帆 / 文心千帆 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "baidu",
      "categories": [
        "model",
        "agent",
        "business"
      ],
      "priority": "medium"
    },
    "wechatBailianSearch": {
      "title": "公众号检索：阿里百炼 / 通义千问",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E9%98%BF%E9%87%8C%E7%99%BE%E7%82%BC%20%E9%80%9A%E4%B9%89%E5%8D%83%E9%97%AE",
      "type": "wechat",
      "note": "公众号检索：阿里百炼 / 通义千问 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "aliyun",
      "categories": [
        "model",
        "agent",
        "multimodal"
      ],
      "priority": "medium"
    },
    "wechatSiliconSearch": {
      "title": "公众号检索：硅基流动 / SiliconFlow",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E7%A1%85%E5%9F%BA%E6%B5%81%E5%8A%A8%20SiliconFlow",
      "type": "wechat",
      "note": "公众号检索：硅基流动 / SiliconFlow 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "silicon",
      "categories": [
        "model",
        "business"
      ],
      "priority": "medium"
    },
    "volcArkApi": {
      "title": "火山方舟接口文档",
      "vendor": "火山方舟",
      "url": "https://www.volcengine.com/docs/82379/1494384?lang=zh",
      "type": "official",
      "note": "火山方舟接口文档 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "volc",
      "categories": [
        "model",
        "agent",
        "multimodal",
        "platform"
      ],
      "priority": "high"
    },
    "baiduPlatform": {
      "title": "百度千帆更新动态",
      "vendor": "百度千帆",
      "url": "https://cloud.baidu.com/doc/qianfan/s/Gmh4stncc",
      "type": "official",
      "note": "百度千帆更新动态 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "official_update_record",
      "competitor": "baidu",
      "categories": [
        "agent",
        "tools",
        "business"
      ],
      "priority": "high"
    },
    "aliyunMcp": {
      "title": "阿里云百炼工具接入文档",
      "vendor": "阿里百炼",
      "url": "https://help.aliyun.com/zh/model-studio/mcp-introduction",
      "type": "official",
      "note": "阿里云百炼工具接入文档 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "aliyun",
      "categories": [
        "agent",
        "tools"
      ],
      "priority": "high"
    },
    "aliyunCodingPlan": {
      "title": "阿里云百炼开发者套餐",
      "vendor": "阿里百炼",
      "url": "https://help.aliyun.com/zh/model-studio/coding-plan",
      "type": "official",
      "note": "阿里云百炼开发者套餐 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "aliyun",
      "categories": [
        "coding",
        "business"
      ],
      "priority": "medium"
    },
    "zhipuExternal": {
      "title": "智谱 BigModel 模型广场",
      "vendor": "智谱 AI",
      "url": "https://bigmodel.cn/console/modelcenter/square",
      "type": "official",
      "note": "智谱 BigModel 模型广场 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "zhipu",
      "categories": [
        "model",
        "agent"
      ],
      "priority": "medium"
    },
    "wechatZhipuSearch": {
      "title": "公众号检索：智谱 AI / GLM",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=%E6%99%BA%E8%B0%B1AI%20GLM%20BigModel",
      "type": "wechat",
      "note": "公众号检索：智谱 AI / GLM 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "zhipu",
      "categories": [
        "model",
        "agent"
      ],
      "priority": "medium"
    },
    "mediaBaiduQianfanSearch": {
      "title": "新闻检索：百度千帆",
      "vendor": "新闻检索",
      "url": "https://www.baidu.com/s?tn=news&rtt=4&bsst=1&cl=2&word=%E7%99%BE%E5%BA%A6%E5%8D%83%E5%B8%86%20%E5%A4%A7%E6%A8%A1%E5%9E%8B%20%E6%9B%B4%E6%96%B0",
      "type": "media",
      "note": "新闻检索：百度千帆 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "baidu",
      "categories": [
        "model",
        "business"
      ],
      "priority": "medium"
    },
    "mediaAliyunBailianSearch": {
      "title": "新闻检索：阿里百炼",
      "vendor": "新闻检索",
      "url": "https://www.baidu.com/s?tn=news&rtt=4&bsst=1&cl=2&word=%E9%98%BF%E9%87%8C%E7%99%BE%E7%82%BC%20%E9%80%9A%E4%B9%89%20%E5%A4%A7%E6%A8%A1%E5%9E%8B",
      "type": "media",
      "note": "新闻检索：阿里百炼 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "aliyun",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "medium"
    },
    "mediaVolcArkSearch": {
      "title": "新闻检索：火山方舟",
      "vendor": "新闻检索",
      "url": "https://www.baidu.com/s?tn=news&rtt=4&bsst=1&cl=2&word=%E7%81%AB%E5%B1%B1%E6%96%B9%E8%88%9F%20%E8%B1%86%E5%8C%85%20%E5%A4%A7%E6%A8%A1%E5%9E%8B",
      "type": "media",
      "note": "新闻检索：火山方舟 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "volc",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "medium"
    },
    "mediaZhipuSearch": {
      "title": "新闻检索：智谱 AI",
      "vendor": "新闻检索",
      "url": "https://www.baidu.com/s?tn=news&rtt=4&bsst=1&cl=2&word=%E6%99%BA%E8%B0%B1AI%20GLM%20BigModel%20%E5%A4%A7%E6%A8%A1%E5%9E%8B",
      "type": "media",
      "note": "新闻检索：智谱 AI 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "recordType": "",
      "competitor": "zhipu",
      "categories": [
        "model",
        "agent",
        "business"
      ],
      "priority": "medium"
    },
    "volcArkModelUpdates": {
      "title": "火山方舟模型更新日志",
      "vendor": "火山方舟",
      "url": "https://console.volcengine.com/ark/region:cn-beijing/docs/82379/1159178?lang=zh",
      "type": "official",
      "recordType": "official_model_update_log",
      "note": "火山方舟模型更新日志 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "competitor": "volc",
      "categories": [
        "model",
        "multimodal"
      ],
      "priority": "high"
    },
    "volcArkPlatformUpdates": {
      "title": "火山方舟平台更新记录",
      "vendor": "火山方舟",
      "url": "https://console.volcengine.com/ark/region:cn-beijing/docs/82379/1159177?lang=zh",
      "type": "official",
      "recordType": "official_update_record",
      "note": "火山方舟平台更新记录 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "competitor": "volc",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high"
    },
    "aliyunModelUpdates": {
      "title": "阿里百炼模型更新日志",
      "vendor": "阿里百炼",
      "url": "https://bailian.console.aliyun.com/cn-beijing?spm=5176.29619931.J__Z58Z6CX7MY__Ll8p1ZOR.1.5709521cDeDXG9&tab=doc#/doc/?type=model&url=2987781",
      "type": "official",
      "recordType": "official_model_update_log",
      "note": "阿里百炼模型更新日志 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "competitor": "aliyun",
      "categories": [
        "model",
        "multimodal"
      ],
      "priority": "high"
    },
    "aliyunPlatformUpdates": {
      "title": "阿里百炼平台更新记录",
      "vendor": "阿里百炼",
      "url": "https://bailian.console.aliyun.com/cn-beijing?spm=5176.29619931.J__Z58Z6CX7MY__Ll8p1ZOR.1.5709521cDeDXG9&tab=doc#/doc/?type=model&url=2987782",
      "type": "official",
      "recordType": "official_update_record",
      "note": "阿里百炼平台更新记录 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "competitor": "aliyun",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high"
    },
    "wechatKimiMoonshotSearch": {
      "title": "公众号检索：月之暗面 / Kimi",
      "vendor": "微信公众平台检索",
      "url": "https://weixin.sogou.com/weixin?type=2&query=Kimi%20K2%20%E6%9C%88%E4%B9%8B%E6%9A%97%E9%9D%A2%20%E5%A4%A7%E6%A8%A1%E5%9E%8B",
      "type": "wechat",
      "note": "公众号检索：月之暗面 / Kimi 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "competitor": "moonshot",
      "categories": [
        "model",
        "agent",
        "coding"
      ],
      "priority": "high",
      "recordType": ""
    },
    "mediaKimiMoonshotSearch": {
      "title": "新闻检索：月之暗面 Kimi",
      "vendor": "新闻检索",
      "url": "https://www.baidu.com/s?tn=news&rtt=4&bsst=1&cl=2&word=Kimi%20K2%20%E6%9C%88%E4%B9%8B%E6%9A%97%E9%9D%A2%20%E5%A4%A7%E6%A8%A1%E5%9E%8B%20%E5%8F%91%E5%B8%83",
      "type": "media",
      "note": "新闻检索：月之暗面 Kimi 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "competitor": "moonshot",
      "categories": [
        "model",
        "agent",
        "coding"
      ],
      "priority": "high",
      "recordType": ""
    },
    "mediaKimiChinaDaily": {
      "title": "China Daily：Moonshot Kimi K3",
      "vendor": "China Daily",
      "url": "https://global.chinadaily.com.cn/a/202607/18/WS6a5ad297a310986e2b465f8a.html",
      "type": "media",
      "note": "China Daily：Moonshot Kimi K3 的自动监测来源，用于追踪竞品功能、模型、宣传和新闻动态。",
      "competitor": "moonshot",
      "categories": [
        "model",
        "agent",
        "coding",
        "multimodal"
      ],
      "priority": "high",
      "recordType": ""
    }
  },
  "competitors": [
    {
      "id": "aliyun",
      "lastSeen": "2026-07-17",
      "watchNext": "自动监测发现新线索，建议人工复核原文后更新功能对比、宣传动作和星辰 MaaS 对应建议。"
    },
    {
      "id": "baidu",
      "lastSeen": "2026-11-12",
      "thesis": "动作最密集：新模型、模型退役、智能体、工具广场、AI 搜索和开发者套餐一起推进。",
      "watchNext": "自动监测发现新线索，建议人工复核原文后更新功能对比、宣传动作和星辰 MaaS 对应建议。"
    },
    {
      "id": "volc",
      "lastSeen": "2026-11-16",
      "watchNext": "自动监测发现新线索，建议人工复核原文后更新功能对比、宣传动作和星辰 MaaS 对应建议。"
    }
  ],
  "events": [
    {
      "id": "record-volc-ark-platform-updates-2026-11-16-dca6d2cd",
      "competitor": "volc",
      "date": "2026-11-16",
      "title": "火山方舟：平台更新记录信号",
      "summary": "更新重点来自火山方舟官方平台更新记录，用于观察平台能力、工具、智能体、批量任务、评测、用量和管理能力变化。",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high",
      "source": "volcArkPlatformUpdates",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-11-16，可作为当天更新记录；火山方舟平台记录更适合判断其 MaaS 产品化方向；星辰 MaaS 可重点对比工具链闭环、用量治理和企业管理能力。",
      "evidence": "命中“工具”：…AI 助手：本页的 Markdown 版本位于 资源 产品公告 产品更新公告 产品更新公告 更新时间 : 2026-11-16 复制全文 本文介绍了方舟平台的新版本产品功能特性，欢迎体验。 模型更新信息请见： 模型发布公告 历史产品更新公告： 产品更新公告 2025 产品更新公告 2024 202610 # 功能模块 功能说明 Agent Plan / C…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-volc-ark-platform-updates-2026-11-13-dd4de817",
      "competitor": "volc",
      "date": "2026-11-13",
      "title": "火山方舟：平台更新记录信号",
      "summary": "更新重点来自火山方舟官方平台更新记录，用于观察平台能力、工具、智能体、批量任务、评测、用量和管理能力变化。",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high",
      "source": "volcArkPlatformUpdates",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-11-13，可作为当天更新记录；火山方舟平台记录更适合判断其 MaaS 产品化方向；星辰 MaaS 可重点对比工具链闭环、用量治理和企业管理能力。",
      "evidence": "命中“工具”：…AI 助手：本页的 Markdown 版本位于 资源 产品公告 产品更新公告 产品更新公告 更新时间 : 2026-11-13 复制全文 本文介绍了方舟平台的新版本产品功能特性，欢迎体验。 模型更新信息请见： 模型发布公告 历史产品更新公告： 产品更新公告 2025 产品更新公告 2024 202610 # 功能模块 功能说明 Agent Plan / C…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-volc-ark-platform-updates-2026-11-12-c9533ad5",
      "competitor": "volc",
      "date": "2026-11-12",
      "title": "火山方舟：平台更新记录信号",
      "summary": "更新重点来自火山方舟官方平台更新记录，用于观察平台能力、工具、智能体、批量任务、评测、用量和管理能力变化。",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high",
      "source": "volcArkPlatformUpdates",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-11-12，可作为当天更新记录；火山方舟平台记录更适合判断其 MaaS 产品化方向；星辰 MaaS 可重点对比工具链闭环、用量治理和企业管理能力。",
      "evidence": "命中“工具”：…AI 助手：本页的 Markdown 版本位于 资源 产品公告 产品更新公告 产品更新公告 更新时间 : 2026-11-12 复制全文 本文介绍了方舟平台的新版本产品功能特性，欢迎体验。 模型更新信息请见： 模型发布公告 历史产品更新公告： 产品更新公告 2025 产品更新公告 2024 202610 # 功能模块 功能说明 Agent Plan / C…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-baidu-qianfan-coding-2026-11-12-28ea99eb",
      "competitor": "baidu",
      "date": "2026-11-12",
      "title": "百度千帆：开发者套餐和 API 使用权益信号",
      "summary": "更新重点集中在 Coding Plan、Token Plan、API Key、额度、续费、套餐迁移和开发者入口。",
      "categories": [
        "coding",
        "business"
      ],
      "priority": "high",
      "source": "baiduCodingPlan",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-11-12，可作为当天更新记录；百度在用套餐和额度降低开发者试用门槛；星辰 MaaS 可关注免费额度、套餐迁移提示和 API 接入路径是否足够清晰。",
      "evidence": "命中“Coding Plan”：…帆·大模型服务及Agent开发平台 平台概览 产品公告 模型服务 Coding Plan 产品升级公告 文档中心 百度千帆·大模型服务及Agent开发平台 平台概览 产品公告 模型服务 Coding Plan 产品升级公告 … 有问题 预约专家咨询 本页目录 概述 变更内容 影响 迁移指南 问题与支持 Coding Plan 产品升级公告 更新时间 ： 2…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-volc-ark-platform-updates-2026-11-04-018e77cc",
      "competitor": "volc",
      "date": "2026-11-04",
      "title": "火山方舟：平台更新记录信号",
      "summary": "更新重点来自火山方舟官方平台更新记录，用于观察平台能力、工具、智能体、批量任务、评测、用量和管理能力变化。",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high",
      "source": "volcArkPlatformUpdates",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-11-04，可作为当天更新记录；火山方舟平台记录更适合判断其 MaaS 产品化方向；星辰 MaaS 可重点对比工具链闭环、用量治理和企业管理能力。",
      "evidence": "命中“工具”：…AI 助手：本页的 Markdown 版本位于 资源 产品公告 产品更新公告 产品更新公告 更新时间 : 2026-11-04 复制全文 本文介绍了方舟平台的新版本产品功能特性，欢迎体验。 模型更新信息请见： 模型发布公告 历史产品更新公告： 产品更新公告 2025 产品更新公告 2024 202610 # 功能模块 功能说明 Agent Plan / C…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-volc-ark-platform-updates-2026-11-02-7feeb28b",
      "competitor": "volc",
      "date": "2026-11-02",
      "title": "火山方舟：平台更新记录信号",
      "summary": "更新重点来自火山方舟官方平台更新记录，用于观察平台能力、工具、智能体、批量任务、评测、用量和管理能力变化。",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high",
      "source": "volcArkPlatformUpdates",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-11-02，可作为当天更新记录；火山方舟平台记录更适合判断其 MaaS 产品化方向；星辰 MaaS 可重点对比工具链闭环、用量治理和企业管理能力。",
      "evidence": "命中“工具”：…AI 助手：本页的 Markdown 版本位于 资源 产品公告 产品更新公告 产品更新公告 更新时间 : 2026-11-02 复制全文 本文介绍了方舟平台的新版本产品功能特性，欢迎体验。 模型更新信息请见： 模型发布公告 历史产品更新公告： 产品更新公告 2025 产品更新公告 2024 202609 # 功能模块 功能说明 模型推理 新增 在线推理（低…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-volc-ark-platform-updates-2026-10-25-92009856",
      "competitor": "volc",
      "date": "2026-10-25",
      "title": "火山方舟：平台更新记录信号",
      "summary": "更新重点来自火山方舟官方平台更新记录，用于观察平台能力、工具、智能体、批量任务、评测、用量和管理能力变化。",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high",
      "source": "volcArkPlatformUpdates",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-10-25，可作为当天更新记录；火山方舟平台记录更适合判断其 MaaS 产品化方向；星辰 MaaS 可重点对比工具链闭环、用量治理和企业管理能力。",
      "evidence": "命中“工具”：…AI 助手：本页的 Markdown 版本位于 资源 产品公告 产品更新公告 产品更新公告 更新时间 : 2026-10-25 复制全文 本文介绍了方舟平台的新版本产品功能特性，欢迎体验。 模型更新信息请见： 模型发布公告 历史产品更新公告： 产品更新公告 2025 产品更新公告 2024 202609 # 功能模块 功能说明 模型推理 新增 在线推理（低…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-volc-ark-platform-updates-2026-10-22-1b59fbfe",
      "competitor": "volc",
      "date": "2026-10-22",
      "title": "火山方舟：平台更新记录信号",
      "summary": "更新重点来自火山方舟官方平台更新记录，用于观察平台能力、工具、智能体、批量任务、评测、用量和管理能力变化。",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high",
      "source": "volcArkPlatformUpdates",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-10-22，可作为当天更新记录；火山方舟平台记录更适合判断其 MaaS 产品化方向；星辰 MaaS 可重点对比工具链闭环、用量治理和企业管理能力。",
      "evidence": "命中“工具”：…AI 助手：本页的 Markdown 版本位于 资源 产品公告 产品更新公告 产品更新公告 更新时间 : 2026-10-22 复制全文 本文介绍了方舟平台的新版本产品功能特性，欢迎体验。 模型更新信息请见： 模型发布公告 历史产品更新公告： 产品更新公告 2025 产品更新公告 2024 202609 # 功能模块 功能说明 模型推理 新增 在线推理（低…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-baidu-qianfan-model-2026-10-18-0f504525",
      "competitor": "baidu",
      "date": "2026-10-18",
      "title": "百度千帆：模型上新、升级和退役节奏信号",
      "summary": "更新重点集中在模型生命周期管理：模型上新、版本升级、旧模型下线/退役，以及 GLM、Kimi、MiniMax、DeepSeek、Qwen 等第三方模型可用性。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-10-18，可作为当天更新记录；百度千帆在强化“模型可选 + 版本治理”的平台心智；星辰 MaaS 可关注模型上下线提醒、替代模型建议和兼容迁移说明。",
      "evidence": "命中“千帆”：…5年7月 2025年6月 2025年5月 2025年4月 2025年3月 2025年2月 2025年1月 2024年12月 2024年11月 2024年10月 2024年9月 2024年8月 2024年7月 2024年6月 2024年5月 2024年4月 2024年3月 2024年2月 2024年1月 2023年及以前发布的模型 模型更新记录 更新时间 ：…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-volc-ark-platform-updates-2026-10-15-145378db",
      "competitor": "volc",
      "date": "2026-10-15",
      "title": "火山方舟：平台更新记录信号",
      "summary": "更新重点来自火山方舟官方平台更新记录，用于观察平台能力、工具、智能体、批量任务、评测、用量和管理能力变化。",
      "categories": [
        "agent",
        "tools",
        "platform",
        "business"
      ],
      "priority": "high",
      "source": "volcArkPlatformUpdates",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-10-15，可作为当天更新记录；火山方舟平台记录更适合判断其 MaaS 产品化方向；星辰 MaaS 可重点对比工具链闭环、用量治理和企业管理能力。",
      "evidence": "命中“工具”：…AI 助手：本页的 Markdown 版本位于 资源 产品公告 产品更新公告 产品更新公告 更新时间 : 2026-10-15 复制全文 本文介绍了方舟平台的新版本产品功能特性，欢迎体验。 模型更新信息请见： 模型发布公告 历史产品更新公告： 产品更新公告 2025 产品更新公告 2024 202609 # 功能模块 功能说明 模型推理 新增 在线推理（低…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-baidu-qianfan-model-2026-10-14-00f42089",
      "competitor": "baidu",
      "date": "2026-10-14",
      "title": "百度千帆：模型上新、升级和退役节奏信号",
      "summary": "更新重点集中在模型生命周期管理：模型上新、版本升级、旧模型下线/退役，以及 GLM、Kimi、MiniMax、DeepSeek、Qwen 等第三方模型可用性。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-10-14，可作为当天更新记录；百度千帆在强化“模型可选 + 版本治理”的平台心智；星辰 MaaS 可关注模型上下线提醒、替代模型建议和兼容迁移说明。",
      "evidence": "命中“千帆”：…5年7月 2025年6月 2025年5月 2025年4月 2025年3月 2025年2月 2025年1月 2024年12月 2024年11月 2024年10月 2024年9月 2024年8月 2024年7月 2024年6月 2024年5月 2024年4月 2024年3月 2024年2月 2024年1月 2023年及以前发布的模型 模型更新记录 更新时间 ：…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-baidu-qianfan-model-2026-09-16-8068e67d",
      "competitor": "baidu",
      "date": "2026-09-16",
      "title": "百度千帆：模型上新、升级和退役节奏信号",
      "summary": "更新重点集中在模型生命周期管理：模型上新、版本升级、旧模型下线/退役，以及 GLM、Kimi、MiniMax、DeepSeek、Qwen 等第三方模型可用性。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-09-16，可作为当天更新记录；百度千帆在强化“模型可选 + 版本治理”的平台心智；星辰 MaaS 可关注模型上下线提醒、替代模型建议和兼容迁移说明。",
      "evidence": "命中“千帆”：…5年7月 2025年6月 2025年5月 2025年4月 2025年3月 2025年2月 2025年1月 2024年12月 2024年11月 2024年10月 2024年9月 2024年8月 2024年7月 2024年6月 2024年5月 2024年4月 2024年3月 2024年2月 2024年1月 2023年及以前发布的模型 模型更新记录 更新时间 ：…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-baidu-qianfan-model-2026-08-28-02cc48e3",
      "competitor": "baidu",
      "date": "2026-08-28",
      "title": "百度千帆：模型上新、升级和退役节奏信号",
      "summary": "更新重点集中在模型生命周期管理：模型上新、版本升级、旧模型下线/退役，以及 GLM、Kimi、MiniMax、DeepSeek、Qwen 等第三方模型可用性。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-08-28，可作为当天更新记录；百度千帆在强化“模型可选 + 版本治理”的平台心智；星辰 MaaS 可关注模型上下线提醒、替代模型建议和兼容迁移说明。",
      "evidence": "命中“千帆”：…2024年2月 2024年1月 2023年及以前发布的模型 模型更新记录 更新时间 ： 2026-08-27 千帆AI应用开发者中心已上线，期待您的 点击 ！ 本文介绍了本平台的新模型发布记录与介绍，相关内容可于 模型广场 进行体验。 产品更新状态可查看： 产品更新动态 。 2026年8月 日期 模型厂商 模型名称 模型版本 模型类型 动态说明 介绍及调用…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-baidu-qianfan-model-2026-08-27-3e50188f",
      "competitor": "baidu",
      "date": "2026-08-27",
      "title": "百度千帆：模型上新、升级和退役节奏信号",
      "summary": "更新重点集中在模型生命周期管理：模型上新、版本升级、旧模型下线/退役，以及 GLM、Kimi、MiniMax、DeepSeek、Qwen 等第三方模型可用性。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-08-27，可作为当天更新记录；百度千帆在强化“模型可选 + 版本治理”的平台心智；星辰 MaaS 可关注模型上下线提醒、替代模型建议和兼容迁移说明。",
      "evidence": "命中“千帆”：…5年7月 2025年6月 2025年5月 2025年4月 2025年3月 2025年2月 2025年1月 2024年12月 2024年11月 2024年10月 2024年9月 2024年8月 2024年7月 2024年6月 2024年5月 2024年4月 2024年3月 2024年2月 2024年1月 2023年及以前发布的模型 模型更新记录 更新时间 ：…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-baidu-qianfan-model-2026-08-19-e6dbd27e",
      "competitor": "baidu",
      "date": "2026-08-19",
      "title": "百度千帆：模型上新、升级和退役节奏信号",
      "summary": "更新重点集中在模型生命周期管理：模型上新、版本升级、旧模型下线/退役，以及 GLM、Kimi、MiniMax、DeepSeek、Qwen 等第三方模型可用性。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-08-19，可作为当天更新记录；百度千帆在强化“模型可选 + 版本治理”的平台心智；星辰 MaaS 可关注模型上下线提醒、替代模型建议和兼容迁移说明。",
      "evidence": "命中“千帆”：…2024年2月 2024年1月 2023年及以前发布的模型 模型更新记录 更新时间 ： 2026-08-18 千帆AI应用开发者中心已上线，期待您的 点击 ！ 本文介绍了本平台的新模型发布记录与介绍，相关内容可于 模型广场 进行体验。 产品更新状态可查看： 产品更新动态 。 2026年8月 日期 模型厂商 模型名称 模型版本 模型类型 动态说明 介绍及调用…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-baidu-qianfan-model-2026-08-18-b8d54261",
      "competitor": "baidu",
      "date": "2026-08-18",
      "title": "百度千帆：模型上新、升级和退役节奏信号",
      "summary": "更新重点集中在模型生命周期管理：模型上新、版本升级、旧模型下线/退役，以及 GLM、Kimi、MiniMax、DeepSeek、Qwen 等第三方模型可用性。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-08-18，可作为当天更新记录；百度千帆在强化“模型可选 + 版本治理”的平台心智；星辰 MaaS 可关注模型上下线提醒、替代模型建议和兼容迁移说明。",
      "evidence": "命中“千帆”：…5年7月 2025年6月 2025年5月 2025年4月 2025年3月 2025年2月 2025年1月 2024年12月 2024年11月 2024年10月 2024年9月 2024年8月 2024年7月 2024年6月 2024年5月 2024年4月 2024年3月 2024年2月 2024年1月 2023年及以前发布的模型 模型更新记录 更新时间 ：…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "record-baidu-qianfan-model-2026-08-17-2de10981",
      "competitor": "baidu",
      "date": "2026-08-17",
      "title": "百度千帆：模型上新、升级和退役节奏信号",
      "summary": "更新重点集中在模型生命周期管理：模型上新、版本升级、旧模型下线/退役，以及 GLM、Kimi、MiniMax、DeepSeek、Qwen 等第三方模型可用性。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台自己的官方更新记录在原文中明确出现 2026-08-17，可作为当天更新记录；百度千帆在强化“模型可选 + 版本治理”的平台心智；星辰 MaaS 可关注模型上下线提醒、替代模型建议和兼容迁移说明。",
      "evidence": "命中“千帆”：…5年7月 2025年6月 2025年5月 2025年4月 2025年3月 2025年2月 2025年1月 2024年12月 2024年11月 2024年10月 2024年9月 2024年8月 2024年7月 2024年6月 2024年5月 2024年4月 2024年3月 2024年2月 2024年1月 2023年及以前发布的模型 模型更新记录 更新时间 ：…",
      "autoRecord": true,
      "recordType": "official_update_record"
    },
    {
      "id": "baidu-20260709-model-retire",
      "competitor": "baidu",
      "date": "2026-07-09",
      "title": "Kimi-K2.5、MiniMax-M2.5 在千帆进入退役记录",
      "summary": "百度千帆模型更新记录显示，2026 年 7 月 9 日 Kimi-K2.5 和 MiniMax-M2.5 退役，并指向模型版本升级及退役机制。",
      "categories": [
        "model",
        "governance"
      ],
      "priority": "high",
      "source": "baiduModel",
      "signal": "平台开始更主动管理模型生命周期，星辰也需要清楚提示模型上下线、替代模型和迁移影响。"
    }
  ],
  "news": [
    {
      "id": "candidate-media-maas-news-volc-2026-11-08",
      "competitor": "volc",
      "date": "2026-11-08",
      "publishedDate": "2026-11-08",
      "publishedDateLabel": "2026-11-08",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-11-14",
      "collectedAt": "2026-11-15 05:06:50",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包上线/发布",
      "summary": "媒体信息提到：...5.5,这款 豆包 图像创作 模型 与上一代Seedream 5.0 Pro相比,生成速度大幅提升。这条信息主要指向模型供给、工具/MCP、图像视频语音、生态/客户案例。",
      "takeaway": "简单说，火山方舟在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "insight": "简单说，火山方舟在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "evidence": "命中“火山方舟”：…5.5,这款 豆包 图像创作 模型 与上一代Seedream 5.0 Pro相比,生成速度大幅提升。 目前,豆包、豆包工作、即梦均已同步接入Seedream 5.5,API即将在火山方舟平台上线。 , dispTime : 6天前 , sourceIcon : , rtses : 同花顺 , sourceName : 同花顺 , accessibility…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 9,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-10-22",
      "competitor": "volc",
      "date": "2026-10-22",
      "publishedDate": "2026-10-22",
      "publishedDateLabel": "2026-10-22",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-10-28",
      "collectedAt": "2026-10-29 05:30:47",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包大模型强调推理成本",
      "summary": "媒体信息提到：...服务大致分为三类,理解它们的差异是选型的第一步。这条信息主要指向模型供给、图像视频语音、价格/优惠。",
      "takeaway": "简单说，火山方舟在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "insight": "简单说，火山方舟在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "evidence": "命中“火山方舟”：…服务大致分为三类,理解它们的差异是选型的第一步。 路线一:云厂商全栈平台。阿里云百炼、火山引擎方舟、腾讯云TI平台属于这一类。优势在于与自家云基础设施深度… CSDN技术社区 火山方舟 (火山引擎 MaaS):依托云厂商背景,与字节系技术栈打通程度较高, 豆包大模型 、云托管、CDN 等服务可联动,合规资质齐全。计费以按量后付费为核心,配套模型单元包月预付…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 9,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-10-21",
      "competitor": "volc",
      "date": "2026-10-21",
      "publishedDate": "2026-10-21",
      "publishedDateLabel": "2026-10-21",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-10-25",
      "collectedAt": "2026-10-26 03:27:05",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包大模型强调推理成本",
      "summary": "媒体信息提到：...头、翻旧账 27 美国UFO文件披露神秘“黑三角” 28 “台湾的抗日是整整50年” 29 苏醒跟好几个朋友闹掰都是一个原因 30 陈...。这条信息主要指向模型供给、图像视频语音、价格/优惠。",
      "takeaway": "简单说，火山方舟在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "insight": "简单说，火山方舟在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "evidence": "命中“火山方舟”：…头、翻旧账 27 美国UFO文件披露神秘“黑三角” 28 “台湾的抗日是整整50年” 29 苏醒跟好几个朋友闹掰都是一个原因 30 陈熠3比0张本美和 夺亚锦赛女单冠军 辅助模式 火山方舟 (火山引擎 MaaS):依托云厂商背景,与字节系技术栈打通程度较高,豆包大模型、云托管、CDN 等服务可联动,合规资质齐全。计费以按量后付费为核心,配套模型单元包月预付…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 9,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-10-16",
      "competitor": "volc",
      "date": "2026-10-16",
      "publishedDate": "2026-10-16",
      "publishedDateLabel": "2026-10-16",
      "dateSource": "published_date",
      "collectedDate": "2026-11-01",
      "collectedAt": "2026-11-02 04:57:37",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包出现市场信号",
      "summary": "豆包出现市场信号。",
      "takeaway": "简单说，火山方舟在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "insight": "简单说，火山方舟在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "evidence": "命中“火山方舟”：…,适合客服录音的批量处理。豆包流式语音识别在实时性和准确率之间取得平衡,适合客服通话的实时转写。豆包实时语音 模型 支持低延迟流式识别,边说边转文字,适合需要实时质检的客服场景。 火山方舟 MaaS平台统一管… , dispTime : 10月16日 , sourceIcon : , rtses : 太平洋电脑网 , sourceName : 太平洋科技 …",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 8,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-10-15",
      "competitor": "volc",
      "date": "2026-10-15",
      "publishedDate": "2026-10-15",
      "publishedDateLabel": "2026-10-15",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-10-20",
      "collectedAt": "2026-10-21 04:17:40",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包出现市场信号",
      "summary": "豆包出现市场信号。",
      "takeaway": "简单说，火山方舟在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "insight": "简单说，火山方舟在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "evidence": "命中“火山方舟”：…,适合客服录音的批量处理。豆包流式语音识别在实时性和准确率之间取得平衡,适合客服通话的实时转写。豆包实时语音 模型 支持低延迟流式识别,边说边转文字,适合需要实时质检的客服场景。 火山方舟 MaaS平台统一管… , dispTime : 5天前 , sourceIcon : , rtses : 太平洋电脑网 , sourceName : 太平洋科技 , a…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 8,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-10-08",
      "competitor": "volc",
      "date": "2026-10-08",
      "publishedDate": "2026-10-08",
      "publishedDateLabel": "2026-10-08",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-10-12",
      "collectedAt": "2026-10-13 07:30:16",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包升级Coding/Agent/VLM能力",
      "summary": "报道提到豆包围绕 Coding、Agent、VLM 三个方向升级，火山方舟继续把模型能力和平台服务打包成对外方案。",
      "takeaway": "星辰 MaaS 可把代码、智能体和视觉理解能力分别做成清晰入口，并配套示例、价格和调用限制说明。",
      "insight": "星辰 MaaS 可把代码、智能体和视觉理解能力分别做成清晰入口，并配套示例、价格和调用限制说明。",
      "evidence": "命中“火山方舟”：…n后付费和资源包预付费两种模式,新用户有一定额度的免费调用。豆包系列… CSDN技术社区 豆包大模型 Doubao-Seed-2.1-pro更新至0915版本,API全量上线 火山方舟 ,豆包工作同步完成升级,TRAE亦已接入。字节CEO梁汝波在2026飞书未来无限大会上作出判断:Agent进入可用阶段后,Agent、模型、协作环境三者必须紧密融合,才能真…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "medium",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-09-29",
      "competitor": "volc",
      "date": "2026-09-29",
      "publishedDate": "2026-09-29",
      "publishedDateLabel": "2026-09-29",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-10-02",
      "collectedAt": "2026-10-03 05:10:14",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包大模型上线/发布",
      "summary": "媒体信息提到：...指高开1.2% 29 黄河“鸳鸯锅”出圈 新 30 意大利公交中国人太多挤到刷不上卡 辅助模式 豆包大模型 Doubao-Seed-2...。这条信息主要指向模型供给、工具/MCP、图像视频语音。",
      "takeaway": "简单说，火山方舟在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "insight": "简单说，火山方舟在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "evidence": "命中“火山方舟”：…指高开1.2% 29 黄河“鸳鸯锅”出圈 新 30 意大利公交中国人太多挤到刷不上卡 辅助模式 豆包大模型 Doubao-Seed-2.1-pro更新至0915版本，API全量上线火山方舟，豆包工作同步完成升级，TRAE亦已接入。字节CEO梁汝波在2026飞书未来无限大会上… , dispTime : 3天前 , sourceIcon :",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "medium",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-09-21",
      "competitor": "volc",
      "date": "2026-09-21",
      "publishedDate": "2026-09-21",
      "publishedDateLabel": "2026-09-21",
      "dateSource": "published_date",
      "collectedDate": "2026-10-04",
      "collectedAt": "2026-10-05 03:54:15",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包升级Coding/Agent/VLM能力",
      "summary": "报道提到豆包围绕 Coding、Agent、VLM 三个方向升级，火山方舟继续把模型能力和平台服务打包成对外方案。",
      "takeaway": "星辰 MaaS 可把代码、智能体和视觉理解能力分别做成清晰入口，并配套示例、价格和调用限制说明。",
      "insight": "星辰 MaaS 可把代码、智能体和视觉理解能力分别做成清晰入口，并配套示例、价格和调用限制说明。",
      "evidence": "命中“火山方舟”：消息面上,9月21日,字节跳动旗下火山引擎宣布 豆包大模型 Doubao-Seed-2.1-Pro更新至0915版本,API在 火山方舟 全量上线,豆包App与编程产品TRAE同步接入,面向Agent与Coding场景的同版本模型同步完成更新;9月18日,工信部等十部门联合印发《医药工业发展“十五五”规划》,提出…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "medium",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 11,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-09-16",
      "competitor": "volc",
      "date": "2026-09-16",
      "publishedDate": "2026-09-16",
      "publishedDateLabel": "2026-09-16",
      "dateSource": "published_date",
      "collectedDate": "2026-11-09",
      "collectedAt": "2026-11-10 08:32:33",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包升级Coding/Agent/VLM能力",
      "summary": "报道提到豆包围绕 Coding、Agent、VLM 三个方向升级，火山方舟继续把模型能力和平台服务打包成对外方案。",
      "takeaway": "星辰 MaaS 可把代码、智能体和视觉理解能力分别做成清晰入口，并配套示例、价格和调用限制说明。",
      "insight": "星辰 MaaS 可把代码、智能体和视觉理解能力分别做成清晰入口，并配套示例、价格和调用限制说明。",
      "evidence": "命中“火山方舟”：北京商报讯（记者 魏蔚）9月16日， 火山 引擎宣布，Doubao-Seed-2.1-pro更新至0915版本，API已全量上线 火山方舟 。本次升级围绕企业生产级需求展开：Agent（智能体）专业任务交付更可靠、多模态Coding（编程）能力强化、多模态理解覆盖3D与专业图文，同时Token效率持续优…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 7,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-09-10",
      "competitor": "volc",
      "date": "2026-09-10",
      "publishedDate": "2026-09-10",
      "publishedDateLabel": "2026-09-10",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-09-12",
      "collectedAt": "2026-09-13 02:57:49",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：doubao-pro-32k调整权益/价格",
      "summary": "媒体信息提到：...Token;doubao-pro-32k输入0.8元/百万Token、输出2.0元/百万Token。这条信息主要指向模型供给、图像视频语音、价格/优惠。",
      "takeaway": "简单说，火山方舟在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "insight": "简单说，火山方舟在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "evidence": "命中“火山方舟”：…Token;doubao-pro-32k输入0.8元/百万Token、输出2.0元/百万Token。相比阿里云百炼文本模型的美元计价,豆包的价格体系对人民币用户更直观。更关键的是,火山方舟平台提供Codi… , dispTime : 前天15:58 , sourceIcon :",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 6,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-09-06",
      "competitor": "volc",
      "date": "2026-09-06",
      "publishedDate": "2026-09-06",
      "publishedDateLabel": "2026-09-06",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-09-08",
      "collectedAt": "2026-09-09 03:44:11",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包升级Coding/Agent/VLM能力",
      "summary": "报道提到豆包围绕 Coding、Agent、VLM 三个方向升级，火山方舟继续把模型能力和平台服务打包成对外方案。",
      "takeaway": "星辰 MaaS 可把代码、智能体和视觉理解能力分别做成清晰入口，并配套示例、价格和调用限制说明。",
      "insight": "星辰 MaaS 可把代码、智能体和视觉理解能力分别做成清晰入口，并配套示例、价格和调用限制说明。",
      "evidence": "命中“火山方舟”：… 版三个来源：1） 豆包 App/电脑版-AI创作- 生成-选择模型 Seedream 5.0 Pro；2）即梦 端- 生成/Agent模式-选择 5.0 Pro；3）火山方舟体验中心-视觉模型- 生成-Doubao-Seedream-5.0-pro。同时支持API调用。以上Seedance和S… , dispTime : 前天09:30 , source…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 6,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-08-27",
      "competitor": "volc",
      "date": "2026-08-27",
      "publishedDate": "2026-08-27",
      "publishedDateLabel": "2026-08-27",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-09-05",
      "collectedAt": "2026-09-06 02:47:45",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包升级Coding/Agent/VLM能力",
      "summary": "公开报道提到，豆包大模型日均 Token 调用量突破 180 万亿，火山方舟服务超过 110 万企业和个人，重点是在用调用规模和客户规模证明平台化进展。",
      "takeaway": "星辰 MaaS 可对比是否把调用规模、客户案例、行业落地和稳定性能力讲清楚，而不只展示模型列表。",
      "insight": "星辰 MaaS 可对比是否把调用规模、客户案例、行业落地和稳定性能力讲清楚，而不只展示模型列表。",
      "evidence": "命中“火山方舟”：…强调极致Token性价比,豆包日均tokens突破50万亿,超100万家企业使用,HiAgent平台已落地中国国航等企业。其优势在推理成本控制与Agent… CSDN技术社区 火山方舟 适合谁:深度依赖 豆包大模型 体系,或本身业务就跑在字节云生态内的团队。 核心优势: 同生态内网延迟极低:如果你的业务和对象存储、CDN、计算资源都放在火山引擎内,同区域调…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "medium",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-baidu-2026-08-17",
      "competitor": "baidu",
      "date": "2026-08-17",
      "publishedDate": "2026-08-17",
      "publishedDateLabel": "2026-08-17",
      "dateSource": "published_date",
      "collectedDate": "2026-08-19",
      "collectedAt": "2026-08-20 01:25:27",
      "kind": "媒体/新闻线索",
      "title": "百度千帆：开发者套餐权益调整",
      "summary": "媒体信息提到：自8月14日起,面向有效订阅用户推出“夜享Tokens加赠计划”:每日21:00至次日08:00,指定前沿模型调用按2折计算。这条信息主要指向模型供给、开发者套餐。",
      "takeaway": "简单说，百度千帆在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "insight": "简单说，百度千帆在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "evidence": "命中“百度千帆”：8月17日消息,百度智能云宣布 百度千帆 Token Plan个人版与企业版同步升级权益。自8月14日起,面向有效订阅用户推出“夜享Tokens加赠计划”:每日21:00至次日08:00,指定前沿模型调用按2折计算。同时,DeepSeek-V4-Flash-0731已上线百度千帆Token Plan,进一步降低开发者和企…",
      "categories": [
        "model",
        "business"
      ],
      "priority": "low",
      "source": "mediaBaiduQianfanSearch",
      "sourceName": "新闻检索：百度千帆",
      "sourceType": "media",
      "keyword": "百度千帆",
      "relevanceScore": 8,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-07-31",
      "competitor": "volc",
      "date": "2026-07-31",
      "publishedDate": "2026-07-31",
      "publishedDateLabel": "2026-07-31",
      "dateSource": "published_date",
      "collectedDate": "2026-08-04",
      "collectedAt": "2026-08-05 04:59:53",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包上线/发布",
      "summary": "媒体信息提到：Seedance 2.5正在陆续上线即梦AI、 豆包 专业版等平台,API服务也将在近期上线 火山方舟。这条信息主要指向模型供给、工具/MCP、图像视频语音。",
      "takeaway": "简单说，火山方舟在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "insight": "简单说，火山方舟在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "evidence": "命中“火山方舟”：Seedance 2.5正在陆续上线即梦AI、 豆包 专业版等平台,API服务也将在近期上线 火山方舟 。 DeepSeek-V4-Flash正式版API上线公测 7月31日消息,DeepSeek-V4-Flash正式版API上线公测。DeepSeek-V4-Flash-0731的 模型 结构、尺寸和DeepSeek-V4-Flash-preview保持一致…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 7,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-07-21",
      "competitor": "volc",
      "date": "2026-07-21",
      "publishedDate": "2026-07-21",
      "publishedDateLabel": "2026-07-21",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-07-24",
      "collectedAt": "2026-07-25 04:50:46",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包大模型强化案例/生态",
      "summary": "媒体信息提到：.... 3天前 作为火山引擎旗下科创扶持载体,V-START加速器携成熟创业生态深度入局。这条信息主要指向模型供给、图像视频语音、生态/客户案例。",
      "takeaway": "简单说，火山方舟在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "insight": "简单说，火山方舟在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "evidence": "命中“火山方舟”：…. 3天前 作为火山引擎旗下科创扶持载体,V-START加速器携成熟创业生态深度入局。依托覆盖2000余家初创企业、赋能70余个优质项目的实践经验,火山引擎行业解决方案专家现场分享火山方舟与豆包大模型的核心技术架构与能力,并结合真实企业场景,拆解大模型在初创企业中的实战应用路… 同花顺财经 火山 引擎达成战略合作 豆包大模型 将深入美妆经营一线 , tit…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "medium",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 11,
      "autoCandidate": true
    },
    {
      "id": "news-media-20260718-kimi-k3",
      "competitor": "moonshot",
      "date": "2026-07-18",
      "publishedDate": "2026-07-18",
      "publishedDateLabel": "2026-07-18",
      "dateSource": "published_date",
      "kind": "媒体/新闻线索",
      "title": "月之暗面 Kimi：Kimi K3 强调长上下文和 Agent 能力",
      "summary": "China Daily 报道称，Moonshot 发布 Kimi K3，强调 2.8T 参数、1M token 上下文、多模态视觉理解、代码生成和 Agent 任务能力，并提供开放权重和 API 调用。",
      "takeaway": "简单说，Kimi 的热度来自“长上下文 + 开源/开放权重 + 代码/Agent + 多模态”的组合；星辰 MaaS 需要关注这类热门模型是否接入、价格是否清楚、长上下文和 Agent 能力如何展示。",
      "categories": [
        "model",
        "agent",
        "coding",
        "multimodal"
      ],
      "priority": "high",
      "source": "mediaKimiChinaDaily",
      "sourceName": "China Daily：Moonshot Kimi K3",
      "sourceType": "media",
      "keyword": "Kimi K3",
      "relevanceScore": 14
    },
    {
      "id": "candidate-wechat-kimi-moonshot-2026-07-17",
      "competitor": "moonshot",
      "date": "2026-07-17",
      "publishedDate": "2026-07-17",
      "publishedDateLabel": "2026-07-17",
      "dateSource": "published_date",
      "collectedDate": "2026-08-03",
      "collectedAt": "2026-08-04 04:46:50",
      "kind": "公众号监测",
      "title": "月之暗面：Kimi热门模型进入市场关注",
      "summary": "公众号信息提到：月之暗面 Kimi K3 大模型 发布概况与技术突破 月之暗面 正式发布新一代 大模型 Kimi K3,7月17日全量上线服务.... 整体...。这条信息主要指向模型供给、智能体/工作流、生态/客户案例。",
      "takeaway": "简单说，月之暗面在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "insight": "简单说，月之暗面在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "evidence": "命中“Kimi”：月之暗面 Kimi K3 大模型 发布概况与技术突破 月之暗面 正式发布新一代 大模型 Kimi K3,7月17日全量上线服务…. 整体扩展效率相比上代 K…",
      "categories": [
        "model",
        "agent",
        "coding"
      ],
      "priority": "medium",
      "source": "wechatKimiMoonshotSearch",
      "sourceName": "公众号检索：月之暗面 / Kimi",
      "sourceType": "wechat",
      "keyword": "Kimi",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-07-15",
      "competitor": "volc",
      "date": "2026-07-15",
      "publishedDate": "2026-07-15",
      "publishedDateLabel": "2026-07-15",
      "dateSource": "relative_publish_date",
      "collectedDate": "2026-07-20",
      "collectedAt": "2026-07-21 04:55:57",
      "kind": "媒体/新闻线索",
      "title": "中国经济新闻网：火山引擎把豆包/方舟打包成企业AI服务",
      "summary": "中国经济新闻网相关报道提到，火山引擎把豆包大模型、火山方舟、向量数据库、知识库、GPU 算力和推荐能力组合成企业级 AI 服务，用于大模型接入、内容生成和推荐系统等场景。",
      "takeaway": "简单说，火山不是只卖模型 API，而是在把模型、知识库、算力和推荐能力做成企业 AI 应用底座；星辰 MaaS 需要把“模型调用 + 知识库/向量库 + 应用落地”讲成一套方案。",
      "insight": "简单说，火山不是只卖模型 API，而是在把模型、知识库、算力和推荐能力做成企业 AI 应用底座；星辰 MaaS 需要把“模型调用 + 知识库/向量库 + 应用落地”讲成一套方案。",
      "evidence": "命中“火山方舟”：…模式 文落地的AI应用--产经动态--中国经济新闻网 5天前 5、火山引擎——字节系大模型平台与数据智能云** 火山引擎是字节跳动旗下的企业级云与AI服务平台,产品包括豆包大模型、火山方舟、向量数据库、知识库、GPU算力与智能推荐等。它把字节体系的算法、数据与内容技术能力开放给企业客户,在大模型接入、内容生成、推荐系统… 中国经济时报 模型 指南 , …",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 9,
      "autoCandidate": true
    },
    {
      "id": "news-media-20260713-china-model-cost",
      "competitor": "zhipu",
      "date": "2026-07-13",
      "kind": "媒体报道",
      "title": "FT：海外企业开始用中国模型降低 AI 成本",
      "summary": "Financial Times 报道称，部分海外企业采用 DeepSeek、Z.ai、Moonshot 等中国模型，看重低成本、代码能力、开放权重和可自托管。",
      "takeaway": "简单说，MaaS 平台的竞争不只是模型强不强，还包括价格、开放度、部署灵活性和企业可控性。",
      "categories": [
        "model",
        "business",
        "platform"
      ],
      "priority": "high",
      "source": "ftChinaModelCost"
    },
    {
      "id": "news-media-20260710-barrons-china-ai",
      "competitor": "aliyun",
      "date": "2026-07-10",
      "kind": "媒体报道",
      "title": "Barron's：市场重新关注中国 AI 公司和云厂商",
      "summary": "Barron's 报道提到，投资者关注阿里、百度等中国 AI 相关公司，核心逻辑是大模型成本优势和 AI 云增长预期。",
      "takeaway": "简单说，资本市场也在把阿里、百度这些 MaaS/云厂商当作中国 AI 基础设施代表来观察。",
      "categories": [
        "business",
        "platform"
      ],
      "priority": "medium",
      "source": "barronsChinaAiStocks"
    },
    {
      "id": "news-media-20260710-zhipu-deepseek",
      "competitor": "zhipu",
      "date": "2026-07-10",
      "kind": "媒体报道",
      "title": "Barron's：智谱和 DeepSeek 成为中国模型竞争焦点",
      "summary": "报道提到智谱 GLM、DeepSeek 的成本优势、融资和模型表现，反映中国模型厂商正在被国际投资者和企业客户关注。",
      "takeaway": "简单说，智谱这类模型公司会继续通过模型能力和价格影响各 MaaS 平台的模型货架。",
      "categories": [
        "model",
        "business"
      ],
      "priority": "medium",
      "source": "barronsZhipuDeepSeek"
    },
    {
      "id": "news-media-20260708-bytedance-chip",
      "competitor": "volc",
      "date": "2026-07-08",
      "kind": "媒体报道",
      "title": "TechRadar：ByteDance 推进 AI 加速芯片，支撑豆包和 Seedance 负载",
      "summary": "TechRadar 报道称，ByteDance 因豆包聊天机器人和 Seedance 视频模型等 AI 负载增长，推进 AI 加速芯片和基础设施自主化。",
      "takeaway": "简单说，火山方舟背后的竞争力可能不只在模型和控制台，也在算力成本、芯片和基础设施储备。",
      "categories": [
        "platform",
        "multimodal"
      ],
      "priority": "high",
      "source": "techradarByteDanceChip"
    },
    {
      "id": "candidate-wechat-volc-ark-2026-06-28",
      "competitor": "volc",
      "date": "2026-06-28",
      "publishedDate": "2026-06-28",
      "publishedDateLabel": "2026-06-28",
      "dateSource": "published_date",
      "collectedDate": "2026-11-18",
      "collectedAt": "2026-11-19 07:15:57",
      "kind": "公众号监测",
      "title": "火山方舟：模型供给上线/发布",
      "summary": "公众号信息提到：火山引擎 吴迪: 火山方舟 加速大模型和大算力应用落地 6月28日,2023 火山引擎 V-Tech体验创新科技峰会上, 火山引擎 正式发布...。这条信息主要指向模型供给、智能体/工作流、生态/客户案例。",
      "takeaway": "简单说，火山方舟在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "insight": "简单说，火山方舟在把模型能力变成可落地的应用流程；星辰 MaaS 需要补足模板、工具接入、权限和运行日志。",
      "evidence": "命中“火山方舟”：火山引擎 吴迪: 火山方舟 加速大模型和大算力应用落地 6月28日,2023 火山引擎 V-Tech体验创新科技峰会上, 火山引擎 正式发布&ldquo; 火山方舟 &rdq…",
      "categories": [
        "model",
        "agent",
        "business"
      ],
      "priority": "medium",
      "source": "wechatVolcArkSearch",
      "sourceName": "公众号检索：火山方舟 / 火山引擎",
      "sourceType": "wechat",
      "keyword": "火山方舟",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-volc-2026-05-15",
      "competitor": "volc",
      "date": "2026-05-15",
      "publishedDate": "2026-05-15",
      "publishedDateLabel": "2026-05-15",
      "dateSource": "published_date",
      "collectedDate": "2026-08-24",
      "collectedAt": "2026-08-25 01:29:53",
      "kind": "媒体/新闻线索",
      "title": "火山方舟：豆包大模型上线/发布",
      "summary": "媒体信息提到：5月15日,2024春季火山引擎 FORCE 原动力大会在北京正式举办。这条信息主要指向模型供给、图像视频语音、训练部署、生态/客户案例。",
      "takeaway": "简单说，火山方舟在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "insight": "简单说，火山方舟在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "evidence": "命中“火山方舟”：5月15日,2024春季火山引擎 FORCE 原动力大会在北京正式举办。会上正式发布了字节跳动 豆包大模型 家族、 火山方舟 2.0、AI 应用及 AI 云基础设施等最新产品。 火山引擎总裁 谭待 火山引擎总裁谭待表示:“企业要做好大模型落地,面临模型效果、推理成本、落地难度的三大关键…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "medium",
      "source": "mediaVolcArkSearch",
      "sourceName": "新闻检索：火山方舟",
      "sourceType": "media",
      "keyword": "火山方舟",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "candidate-media-maas-news-aliyun-2026-04-09",
      "competitor": "aliyun",
      "date": "2026-04-09",
      "publishedDate": "2026-04-09",
      "publishedDateLabel": "2026-04-09",
      "dateSource": "published_date",
      "collectedDate": "2026-11-08",
      "collectedAt": "2026-11-09 04:57:45",
      "kind": "媒体/新闻线索",
      "title": "阿里百炼：kimi上线/发布",
      "summary": "媒体信息提到：...业市场创造社会价值，AI正在推动各行各业的生产力变革， 通义大模型 将深耕企业市场。这条信息主要指向模型供给、工具/MCP、图像视频语音、价格/优惠。",
      "takeaway": "简单说，阿里百炼在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "insight": "简单说，阿里百炼在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "evidence": "命中“阿里百炼”：…业市场创造社会价值，AI正在推动各行各业的生产力变革， 通义大模型 将深耕企业市场。”4月9日，在阿里云AI势能大会上，阿里云智能集团资深副总裁、公共云… 君 去 搜： 阿里百炼 通义 大模型 相关搜索 阿里百炼学生优惠 通义千问和千问大模型区别 百炼大模型官网入口 阿里百炼云平台官网 阿里通义千问发布开源模型 阿里云百炼模型官宣降价 阿里百炼大模型平台k…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "medium",
      "source": "mediaAliyunBailianSearch",
      "sourceName": "新闻检索：阿里百炼",
      "sourceType": "media",
      "keyword": "阿里百炼",
      "relevanceScore": 10,
      "autoCandidate": true
    },
    {
      "id": "news-media-20260213-volcano-ai-cloud",
      "competitor": "volc",
      "date": "2026-02-13",
      "kind": "媒体报道",
      "title": "FT：ByteDance 通过火山引擎加码 AI 云",
      "summary": "Financial Times 报道称，ByteDance 正通过火山引擎和 AI 平台挑战阿里、腾讯、华为等云厂商，并受益于模型、算力和消费级生态。",
      "takeaway": "简单说，火山方舟要按“AI 云平台”来看，不只是豆包模型 API。",
      "categories": [
        "platform",
        "business",
        "agent"
      ],
      "priority": "high",
      "source": "ftVolcanoCloud"
    },
    {
      "id": "candidate-media-maas-news-aliyun-2025-09-06",
      "competitor": "aliyun",
      "date": "2025-09-06",
      "publishedDate": "2025-09-06",
      "publishedDateLabel": "2025-09-06",
      "dateSource": "published_date",
      "collectedDate": "2026-11-12",
      "collectedAt": "2026-11-13 06:35:09",
      "kind": "媒体/新闻线索",
      "title": "阿里百炼：Qwen3上线/发布",
      "summary": "媒体信息提到：...mmary : 智东西9月6日报道，昨夜，阿里上线Qwen3系列最强 模型 Qwen3-Max的Preview版本，这也是阿里迄今为止...。这条信息主要指向模型供给、图像视频语音。",
      "takeaway": "简单说，阿里百炼在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "insight": "简单说，阿里百炼在强化多模态任务入口；星辰 MaaS 需要把图片、视频、语音能力做成可试用、可比较、可计费的任务体验。",
      "evidence": "命中“阿里百炼”：…mmary : 智东西9月6日报道，昨夜，阿里上线Qwen3系列最强 模型 Qwen3-Max的Preview版本，这也是阿里迄今为止最大的模型，参数量超1万亿。该模型目前已登陆 阿里百炼 平台，且在 通义 千问应用及Qwen C… , dispTime : 2025年9月6日 , sourceIcon :",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaAliyunBailianSearch",
      "sourceName": "新闻检索：阿里百炼",
      "sourceType": "media",
      "keyword": "阿里百炼",
      "relevanceScore": 9,
      "autoCandidate": true
    },
    {
      "id": "news-media-202504-baidu-multimodal",
      "competitor": "baidu",
      "date": "2025-04-25",
      "kind": "媒体报道",
      "title": "FT：百度用多模态和千帆生态回应 DeepSeek 竞争",
      "summary": "Financial Times 报道称，百度推出 ERNIE 4.5 Turbo、X1 Turbo 等多模态模型，并把 DeepSeek 接入千帆企业平台。",
      "takeaway": "简单说，百度千帆的方向是“自有模型 + 外部热门模型 + 多模态 + 企业平台”一起做。",
      "categories": [
        "model",
        "multimodal",
        "platform"
      ],
      "priority": "medium",
      "source": "ftBaiduMultimodal"
    },
    {
      "id": "candidate-media-maas-news-aliyun-2024-11-01",
      "competitor": "aliyun",
      "date": "2024-11-01",
      "publishedDate": "2024-11-01",
      "publishedDateLabel": "2024-11-01",
      "dateSource": "published_date",
      "collectedDate": "2026-10-31",
      "collectedAt": "2026-11-01 04:23:32",
      "kind": "媒体/新闻线索",
      "title": "阿里百炼：kimi上线/发布",
      "summary": "媒体信息提到：...月消费者信心指数跌至五个月低点 通胀预期略有上升 财联社 7分钟前 阿里大模型通义 上线代码模式 可“大白话”生成应用 新华财经 20...。这条信息主要指向模型供给、工具/MCP、图像视频语音、价格/优惠。",
      "takeaway": "简单说，阿里百炼在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "insight": "简单说，阿里百炼在争夺开发者试用和持续调用成本心智；星辰 MaaS 需要把价格、免费额度、套餐边界和迁移成本说清楚。",
      "evidence": "命中“阿里百炼”：…月消费者信心指数跌至五个月低点 通胀预期略有上升 财联社 7分钟前 阿里大模型通义 上线代码模式 可“大白话”生成应用 新华财经 2024-11-1… 东方财富网 去 搜： 阿里百炼 通义 大模型 相关搜索 阿里百炼云平台官网 百炼大模型官网入口 阿里百炼大模型 阿里云tokenplan 阿里云百炼apikey 通义大模型官网 大模型api平台 阿里百炼学…",
      "categories": [
        "model",
        "multimodal",
        "business"
      ],
      "priority": "low",
      "source": "mediaAliyunBailianSearch",
      "sourceName": "新闻检索：阿里百炼",
      "sourceType": "media",
      "keyword": "阿里百炼",
      "relevanceScore": 9,
      "autoCandidate": true
    }
  ],
  "strategies": [],
  "monitorRuns": [
    {
      "targetDate": "2026-11-18",
      "runDateTime": "2026-11-19 07:15:57",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 1,
      "candidates": 23,
      "modelUpdates": 23,
      "errors": 0
    },
    {
      "targetDate": "2026-11-17",
      "runDateTime": "2026-11-18 07:44:40",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 1,
      "candidates": 22,
      "modelUpdates": 23,
      "errors": 2
    },
    {
      "targetDate": "2026-11-16",
      "runDateTime": "2026-11-17 08:39:11",
      "sourcesChecked": 27,
      "exactMatches": 1,
      "publishedCandidates": 1,
      "candidates": 21,
      "modelUpdates": 23,
      "errors": 2
    },
    {
      "targetDate": "2026-11-15",
      "runDateTime": "2026-11-16 05:28:47",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 1,
      "candidates": 22,
      "modelUpdates": 23,
      "errors": 3
    },
    {
      "targetDate": "2026-11-14",
      "runDateTime": "2026-11-15 05:06:50",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 2,
      "candidates": 24,
      "modelUpdates": 23,
      "errors": 2
    },
    {
      "targetDate": "2026-11-13",
      "runDateTime": "2026-11-14 06:23:31",
      "sourcesChecked": 27,
      "exactMatches": 1,
      "publishedCandidates": 2,
      "candidates": 23,
      "modelUpdates": 23,
      "errors": 2
    },
    {
      "targetDate": "2026-11-12",
      "runDateTime": "2026-11-13 06:35:09",
      "sourcesChecked": 27,
      "exactMatches": 2,
      "publishedCandidates": 3,
      "candidates": 21,
      "modelUpdates": 23,
      "errors": 3
    },
    {
      "targetDate": "2026-11-11",
      "runDateTime": "2026-11-12 07:17:54",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 1,
      "candidates": 22,
      "modelUpdates": 23,
      "errors": 3
    },
    {
      "targetDate": "2026-11-10",
      "runDateTime": "2026-11-11 06:08:36",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 1,
      "candidates": 21,
      "modelUpdates": 23,
      "errors": 4
    },
    {
      "targetDate": "2026-11-09",
      "runDateTime": "2026-11-10 08:32:33",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 2,
      "candidates": 24,
      "modelUpdates": 23,
      "errors": 1
    },
    {
      "targetDate": "2026-11-08",
      "runDateTime": "2026-11-09 04:57:45",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 2,
      "candidates": 24,
      "modelUpdates": 23,
      "errors": 0
    },
    {
      "targetDate": "2026-11-07",
      "runDateTime": "2026-11-08 04:40:10",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 1,
      "candidates": 24,
      "modelUpdates": 23,
      "errors": 0
    },
    {
      "targetDate": "2026-11-06",
      "runDateTime": "2026-11-07 05:56:14",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 1,
      "candidates": 24,
      "modelUpdates": 23,
      "errors": 0
    },
    {
      "targetDate": "2026-11-05",
      "runDateTime": "2026-11-06 06:33:12",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 1,
      "candidates": 24,
      "modelUpdates": 23,
      "errors": 0
    },
    {
      "targetDate": "2026-11-04",
      "runDateTime": "2026-11-05 06:25:42",
      "sourcesChecked": 27,
      "exactMatches": 1,
      "publishedCandidates": 1,
      "candidates": 23,
      "modelUpdates": 23,
      "errors": 0
    },
    {
      "targetDate": "2026-11-03",
      "runDateTime": "2026-11-04 06:11:56",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 1,
      "candidates": 24,
      "modelUpdates": 23,
      "errors": 0
    },
    {
      "targetDate": "2026-11-02",
      "runDateTime": "2026-11-03 07:47:05",
      "sourcesChecked": 27,
      "exactMatches": 1,
      "publishedCandidates": 1,
      "candidates": 23,
      "modelUpdates": 23,
      "errors": 0
    },
    {
      "targetDate": "2026-11-01",
      "runDateTime": "2026-11-02 04:57:37",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 2,
      "candidates": 24,
      "modelUpdates": 23,
      "errors": 0
    },
    {
      "targetDate": "2026-10-31",
      "runDateTime": "2026-11-01 04:23:32",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 3,
      "candidates": 23,
      "modelUpdates": 23,
      "errors": 1
    },
    {
      "targetDate": "2026-10-30",
      "runDateTime": "2026-10-31 05:22:35",
      "sourcesChecked": 27,
      "exactMatches": 0,
      "publishedCandidates": 3,
      "candidates": 24,
      "modelUpdates": 23,
      "errors": 0
    }
  ],
  "modelUpdates": [
    {
      "id": "model-update-volc-ark-model-updates-2026-11-16-c1318ade",
      "competitor": "volc",
      "date": "2026-11-16",
      "title": "火山方舟：doubao-seed-evolving、doubao-seedance-2-5-flash-261115、Doubao、doubao-seedream-5-5-261028、豆包 下线",
      "summary": "doubao-seed-evolving、doubao-seedance-2-5-flash-261115、Doubao、doubao-seedream-5-5-261028 出现下线动作；复制全文 本文介绍了火山方舟大模型服务平台的新模型发布记录与特性，欢迎体验。 产品功能更新公告请见： 产品更新公告 历史模型发布公告 ： 模型发布公告 2025 模型发布公告 2024 202611 # 提供方 模型 ID 模型类型 版本说明 其它说明 字...",
      "models": [
        "doubao-seed-evolving",
        "doubao-seedance-2-5-flash-261115",
        "Doubao",
        "doubao-seedream-5-5-261028",
        "豆包",
        "kimi-k3-1-pro-261024",
        "Kimi",
        "deepseek-v4-1-flash-261017"
      ],
      "updateType": "下线",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "volcArkModelUpdates",
      "evidence": "命中“doubao-seed-evolving”：复制全文 本文介绍了火山方舟大模型服务平台的新模型发布记录与特性，欢迎体验。 产品功能更新公告请见： 产品更新公告 历史模型发布公告 ： 模型发布公告 2025 模型发布公告 2024 202611 # 提供方 模型 ID 模型类型 版本说明 其它说明 字节跳动 doubao-seed-evolving 深度思考模型 更新 Seed-Evolving 版本更…",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-10-18-1e514ac3",
      "competitor": "baidu",
      "date": "2026-10-18",
      "title": "百度千帆：DeepSeek-V4.1-Flash、DeepSeek-V4.1-Flash-1017、DeepSeek 上新",
      "summary": "DeepSeek-V4.1-Flash、DeepSeek-V4.1-Flash-1017、DeepSeek 出现上新动作；杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4.1-Flash DeepSeek-V4.1-Flash-1017 推理服务API V2版本-文本生成 上新 DeepSeek V4.1 Flash 新版本：许愿式编程一键成真  API调用文档",
      "models": [
        "DeepSeek-V4.1-Flash",
        "DeepSeek-V4.1-Flash-1017",
        "DeepSeek"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“DeepSeek-V4.1-Flash”：杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4.1-Flash DeepSeek-V4.1-Flash-1017 推理服务API V2版本-文本生成 上新 DeepSeek V4.1 Flash 新版本：许愿式编程一键成真 调用说明请查看： API调用文档",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-09-10-ae604316",
      "competitor": "baidu",
      "date": "2026-09-10",
      "title": "百度千帆：DeepSeek-V4.1-Flash、DeepSeek、DeepSeek-V4-Pro 上新",
      "summary": "DeepSeek-V4.1-Flash、DeepSeek、DeepSeek-V4-Pro 出现上新动作；杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4.1-Flash DeepSeek-V4.1-Flash 推理服务API V2版本-文本生成 上新 DeepSeek-V4.1-Flash 是 DeepSeek 全新架构系列中的轻量旗舰模型，...",
      "models": [
        "DeepSeek-V4.1-Flash",
        "DeepSeek",
        "DeepSeek-V4-Pro"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“DeepSeek-V4.1-Flash”：杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4.1-Flash DeepSeek-V4.1-Flash 推理服务API V2版本-文本生成 上新 DeepSeek-V4.1-Flash 是 DeepSeek 全新架构系列中的轻量旗舰模型，以 552B 总参数 MoE 实现越级智能，在多项基准上超越包括 DeepSeek-V4-Pro 在内的…",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-08-28-9921b2dc",
      "competitor": "baidu",
      "date": "2026-08-28",
      "title": "百度千帆：GLM-5.3-Flash、GLM-5、GLM-5.2 上新",
      "summary": "GLM-5.3-Flash、GLM-5、GLM-5.2 出现上新动作；北京智谱华章科技有限公司 GLM-5.3-Flash GLM-5.3-Flash 推理服务API V2版本-文本生成 上新 GLM-5.3-Flash 是 GLM-5 系列首个原生多模态模型，以极致低成本架构实现超越 GLM-5.2 的更强智能。GLM-5...",
      "models": [
        "GLM-5.3-Flash",
        "GLM-5",
        "GLM-5.2"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“GLM-5.3-Flash”：北京智谱华章科技有限公司 GLM-5.3-Flash GLM-5.3-Flash 推理服务API V2版本-文本生成 上新 GLM-5.3-Flash 是 GLM-5 系列首个原生多模态模型，以极致低成本架构实现超越 GLM-5.2 的更强智能。GLM-5.3-Flash 能够原生理解 ，生成可交互代码等专业任务。 调用说明请查看： API调用文档",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-08-19-929ba5f0",
      "competitor": "baidu",
      "date": "2026-08-19",
      "title": "百度千帆：GLM-5.3 上新",
      "summary": "GLM-5.3 出现上新动作；北京智谱华章科技有限公司 GLM-5.3 GLM-5.3 推理服务API V2版本-文本生成 上新 GLM-5.3是智谱最新旗舰模型，以极致后训练 Scaling 实现能力跃迁：编程体验较前代提升 50%，网络安全能力持平 Mythos 5。  API调用文档",
      "models": [
        "GLM-5.3"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“GLM-5.3”：北京智谱华章科技有限公司 GLM-5.3 GLM-5.3 推理服务API V2版本-文本生成 上新 GLM-5.3是智谱最新旗舰模型，以极致后训练 Scaling 实现能力跃迁：编程体验较前代提升 50%，网络安全能力持平 Mythos 5。 调用说明请查看： API调用文档",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-08-14-97f5d018",
      "competitor": "baidu",
      "date": "2026-08-14",
      "title": "百度千帆：DeepSeek-V4-Pro、DeepSeek-V4-Pro-0813、DeepSeek-V4 上新",
      "summary": "DeepSeek-V4-Pro、DeepSeek-V4-Pro-0813、DeepSeek-V4 出现上新动作；杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4-Pro DeepSeek-V4-Pro-0813 推理服务API V2版本-文本生成 上新 DeepSeek-V4 拥有百万字超长上下文，在 Agent 能力、世界知识和推理性能上均实现国内...",
      "models": [
        "DeepSeek-V4-Pro",
        "DeepSeek-V4-Pro-0813",
        "DeepSeek-V4"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“DeepSeek-V4-Pro”：杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4-Pro DeepSeek-V4-Pro-0813 推理服务API V2版本-文本生成 上新 DeepSeek-V4 拥有百万字超长上下文，在 Agent 能力、世界知识和推理性能上均实现国内与开源领域的领先。 调用说明请查看： API调用文档",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-08-01-97e9bdf2",
      "competitor": "baidu",
      "date": "2026-08-01",
      "title": "百度千帆：DeepSeek-V4-Flash、DeepSeek-V4-Flash-0731、DeepSeek-V4-Pro 上新",
      "summary": "DeepSeek-V4-Flash、DeepSeek-V4-Flash-0731、DeepSeek-V4-Pro 出现上新动作；杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4-Flash DeepSeek-V4-Flash-0731 推理服务API V2版本-文本生成 上新 相比 DeepSeek-V4-Pro，V4-Flash 在世界知识储备方面稍逊一筹，但展现...",
      "models": [
        "DeepSeek-V4-Flash",
        "DeepSeek-V4-Flash-0731",
        "DeepSeek-V4-Pro"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“DeepSeek-V4-Flash”：杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4-Flash DeepSeek-V4-Flash-0731 推理服务API V2版本-文本生成 上新 相比 DeepSeek-V4-Pro，V4-Flash 在世界知识储备方面稍逊一筹，但展现出了接近的推理能力。由于模型参数和激活更小，能够提供更加快捷、经济的 API 服务。 调用说明请查看： …",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-aliyun-bailian-model-updates-2026-07-15-1f41bad8",
      "competitor": "aliyun",
      "date": "2026-07-15",
      "title": "阿里百炼：pixverse/pixverse-lipsync 上新",
      "summary": "pixverse/pixverse-lipsync 出现上新动作；视频对口型模型上线：输入视频和音频，生成口型与音频同步的视频。",
      "models": [
        "pixverse/pixverse-lipsync"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "aliyunModelUpdates",
      "evidence": "命中“pixverse/pixverse-lipsync”：视频对口型模型上线：输入视频和音频，生成口型与音频同步的视频。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-aliyun-bailian-model-updates-2026-07-15-79451dea",
      "competitor": "aliyun",
      "date": "2026-07-15",
      "title": "阿里百炼：pixverse/pixverse-motioncontrol 上新",
      "summary": "pixverse/pixverse-motioncontrol 出现上新动作；视频动作模仿模型上线：输入视频和参考动作视频，生成模仿参考动作的视频。",
      "models": [
        "pixverse/pixverse-motioncontrol"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "aliyunModelUpdates",
      "evidence": "命中“pixverse/pixverse-motioncontrol”：视频动作模仿模型上线：输入视频和参考动作视频，生成模仿参考动作的视频。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-aliyun-bailian-model-updates-2026-07-15-9e4b8008",
      "competitor": "aliyun",
      "date": "2026-07-15",
      "title": "阿里百炼：pixverse/pixverse-upscale 上新",
      "summary": "pixverse/pixverse-upscale 出现上新动作；视频超清模型上线：将低分辨率视频提升至更高分辨率。",
      "models": [
        "pixverse/pixverse-upscale"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "aliyunModelUpdates",
      "evidence": "命中“pixverse/pixverse-upscale”：视频超清模型上线：将低分辨率视频提升至更高分辨率。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-aliyun-bailian-model-updates-2026-07-14-fff9d9f9",
      "competitor": "aliyun",
      "date": "2026-07-14",
      "title": "阿里百炼：qwen-audio-3.0-realtime-plus、qwen-audio-3.0-realtime-flash 上新",
      "summary": "qwen-audio-3.0-realtime-plus、qwen-audio-3.0-realtime-flash 出现上新动作；Qwen-Audio 实时语音大模型上线，面向端到端实时语音对话。",
      "models": [
        "qwen-audio-3.0-realtime-plus",
        "qwen-audio-3.0-realtime-flash"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "aliyunModelUpdates",
      "evidence": "命中“qwen-audio-3.0-realtime-plus”：Qwen-Audio 实时语音大模型上线，面向端到端实时语音对话。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-aliyun-bailian-model-updates-2026-07-14-0d06f053",
      "competitor": "aliyun",
      "date": "2026-07-14",
      "title": "阿里百炼：qwen-audio-3.0-tts-plus、qwen-audio-3.0-tts-flash 上新",
      "summary": "qwen-audio-3.0-tts-plus、qwen-audio-3.0-tts-flash 出现上新动作；Qwen-Audio-TTS 语音合成模型上线，增强多语种和中文方言支持。",
      "models": [
        "qwen-audio-3.0-tts-plus",
        "qwen-audio-3.0-tts-flash"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "aliyunModelUpdates",
      "evidence": "命中“qwen-audio-3.0-tts-plus”：Qwen-Audio-TTS 语音合成模型上线，增强多语种和中文方言支持。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-aliyun-bailian-model-updates-2026-07-13-a92b2397",
      "competitor": "aliyun",
      "date": "2026-07-13",
      "title": "阿里百炼：vidu/vidu-image_reference2image、vidu/viduq3-fast_reference2image、vidu/viduq2-reference2image 上新",
      "summary": "vidu/vidu-image_reference2image、vidu/viduq3-fast_reference2image、vidu/viduq2-reference2image 出现上新动作；Vidu 系列图片生成 API 服务上线，支持多图参考、精准还原和高质量生成。",
      "models": [
        "vidu/vidu-image_reference2image",
        "vidu/viduq3-fast_reference2image",
        "vidu/viduq2-reference2image"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "aliyunModelUpdates",
      "evidence": "命中“vidu/vidu-image_reference2image”：Vidu 系列 生成 API 服务上线，支持多图参考、精准还原和高质量生成。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-07-09-9aa9ba3d",
      "competitor": "baidu",
      "date": "2026-07-09",
      "title": "百度千帆：Kimi-K2.5 下线",
      "summary": "Kimi-K2.5 出现下线动作；北京月之暗面科技有限公司 Kimi-K2.5 Kimi-K2.5 推理服务API V2版本-文本生成 退役 模型下线，需查看替代模型。 模型版本升级及退役机制",
      "models": [
        "Kimi-K2.5"
      ],
      "updateType": "下线",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“Kimi-K2.5”：北京月之暗面科技有限公司 Kimi-K2.5 Kimi-K2.5 推理服务API V2版本-文本生成 退役 模型下线，推荐替换模型请查看： 模型版本升级及退役机制",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-07-09-c04a7def",
      "competitor": "baidu",
      "date": "2026-07-09",
      "title": "百度千帆：MiniMax-M2.5 下线",
      "summary": "MiniMax-M2.5 出现下线动作；上海稀宇科技有限公司 MiniMax-M2.5 MiniMax-M2.5 推理服务API V2版本-文本生成 退役 模型下线，需查看替代模型。 模型版本升级及退役机制",
      "models": [
        "MiniMax-M2.5"
      ],
      "updateType": "下线",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“MiniMax-M2.5”：上海稀宇科技有限公司 MiniMax-M2.5 MiniMax-M2.5 推理服务API V2版本-文本生成 退役 模型下线，推荐替换模型请查看： 模型版本升级及退役机制",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-volc-ark-model-updates-2026-07-cf0871bd",
      "competitor": "volc",
      "date": "2026-07",
      "title": "火山方舟：豆包大模型家族 上新",
      "summary": "豆包大模型家族 出现上新动作；火山方舟官方模型发布公告在 2026.07.14 更新；静态抓取未返回精确日明细，按 7 月模型发布记录展示。公众号/新闻线索同时提到豆包大模型家族发布、火山方舟升级。",
      "models": [
        "豆包大模型家族"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "volcArkModelUpdates",
      "evidence": "命中“豆包大模型家族”：火山方舟官方模型发布公告在 2026.07.14 更新；静态抓取未返回精确日明细，按 7 月模型发布记录展示。公众号/新闻线索同时提到豆包大模型家族发布、火山方舟升级。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-volc-ark-model-updates-2026-07-2d7724ca",
      "competitor": "volc",
      "date": "2026-07",
      "title": "火山方舟：豆包 Coding 方向模型 上新",
      "summary": "豆包 Coding 方向模型 出现上新动作；火山方舟 7 月模型发布信号覆盖 Coding 方向能力升级；官方静态页面未返回精确模型规格，先按月度上新/升级信号展示。",
      "models": [
        "豆包 Coding 方向模型"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "volcArkModelUpdates",
      "evidence": "命中“豆包 Coding 方向模型”：火山方舟 7 月模型发布信号覆盖 Coding 方向能力升级；官方静态页面未返回精确模型规格，先按月度上新/升级信号展示。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-volc-ark-model-updates-2026-07-565e5b74",
      "competitor": "volc",
      "date": "2026-07",
      "title": "火山方舟：豆包 Agent 方向模型 上新",
      "summary": "豆包 Agent 方向模型 出现上新动作；火山方舟 7 月模型发布信号覆盖 Agent 方向能力升级；官方静态页面未返回精确模型规格，先按月度上新/升级信号展示。",
      "models": [
        "豆包 Agent 方向模型"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "volcArkModelUpdates",
      "evidence": "命中“豆包 Agent 方向模型”：火山方舟 7 月模型发布信号覆盖 Agent 方向能力升级；官方静态页面未返回精确模型规格，先按月度上新/升级信号展示。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-volc-ark-model-updates-2026-07-631650ed",
      "competitor": "volc",
      "date": "2026-07",
      "title": "火山方舟：豆包 VLM 方向模型 上新",
      "summary": "豆包 VLM 方向模型 出现上新动作；火山方舟 7 月模型发布信号覆盖 VLM/视觉理解方向能力升级；官方静态页面未返回精确模型规格，先按月度上新/升级信号展示。",
      "models": [
        "豆包 VLM 方向模型"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "volcArkModelUpdates",
      "evidence": "命中“豆包 VLM 方向模型”：火山方舟 7 月模型发布信号覆盖 VLM/视觉理解方向能力升级；官方静态页面未返回精确模型规格，先按月度上新/升级信号展示。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-06-17-c0e0935b",
      "competitor": "baidu",
      "date": "2026-06-17",
      "title": "百度千帆：GLM-5.2 上新",
      "summary": "GLM-5.2 出现上新动作；北京智谱华章科技有限公司 GLM-5.2 GLM-5.2 推理服务API V2版本-文本生成 上新 GLM-5.2 是面向长任务时代的旗舰模型。支持更长上下文，长程任务执行更稳定、工程规范遵循更可靠，开发场景成功率进一步提升。  API调用文档",
      "models": [
        "GLM-5.2"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“GLM-5.2”：北京智谱华章科技有限公司 GLM-5.2 GLM-5.2 推理服务API V2版本-文本生成 上新 GLM-5.2 是面向长任务时代的旗舰模型。支持更长上下文，长程任务执行更稳定、工程规范遵循更可靠，开发场景成功率进一步提升。 调用说明请查看： API调用文档",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-04-24-a7f04178",
      "competitor": "baidu",
      "date": "2026-04-24",
      "title": "百度千帆：DeepSeek-V4-Pro、DeepSeek-V4 上新",
      "summary": "DeepSeek-V4-Pro、DeepSeek-V4 出现上新动作；杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4-Pro DeepSeek-V4-Pro 推理服务API V2版本-文本生成 上新 DeepSeek-V4 拥有百万字超长上下文，在 Agent 能力、世界知识和推理性能上均实现国内与开源领域...",
      "models": [
        "DeepSeek-V4-Pro",
        "DeepSeek-V4"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“DeepSeek-V4-Pro”：杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4-Pro DeepSeek-V4-Pro 推理服务API V2版本-文本生成 上新 DeepSeek-V4 拥有百万字超长上下文，在 Agent 能力、世界知识和推理性能上均实现国内与开源领域的领先。 调用说明请查看： API调用文档",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-04-24-4776716e",
      "competitor": "baidu",
      "date": "2026-04-24",
      "title": "百度千帆：DeepSeek-V4-Flash、DeepSeek-V4-Pro 上新",
      "summary": "DeepSeek-V4-Flash、DeepSeek-V4-Pro 出现上新动作；杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4-Flash DeepSeek-V4-Flash 推理服务API V2版本-文本生成 上新 相比 DeepSeek-V4-Pro，V4-Flash 在世界知识储备方面稍逊一筹，但展现出了接近的...",
      "models": [
        "DeepSeek-V4-Flash",
        "DeepSeek-V4-Pro"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“DeepSeek-V4-Flash”：杭州深度求索人工智能基础技术研究有限公司 DeepSeek-V4-Flash DeepSeek-V4-Flash 推理服务API V2版本-文本生成 上新 相比 DeepSeek-V4-Pro，V4-Flash 在世界知识储备方面稍逊一筹，但展现出了接近的推理能力。由于模型参数和激活更小，能够提供更加快捷、经济的 API 服务。 当前仅支持邀测体验。",
      "autoModelUpdate": true
    },
    {
      "id": "model-update-baidu-qianfan-model-2026-04-08-c2592400",
      "competitor": "baidu",
      "date": "2026-04-08",
      "title": "百度千帆：GLM-5.1、Claude 上新",
      "summary": "GLM-5.1、Claude 出现上新动作；北京智谱华章科技有限公司 GLM-5.1 GLM-5.1 推理服务API V2版本-文本生成 上新 GLM-5.1 是智谱新一代旗舰基座，长程任务显著提升，可自主工作长达8小时，闭环交付工程级成果，整体表现对齐Claude Opus 4.6。  API调用文档",
      "models": [
        "GLM-5.1",
        "Claude"
      ],
      "updateType": "上新",
      "categories": [
        "model"
      ],
      "priority": "high",
      "source": "baiduModel",
      "evidence": "命中“GLM-5.1”：北京智谱华章科技有限公司 GLM-5.1 GLM-5.1 推理服务API V2版本-文本生成 上新 GLM-5.1 是智谱新一代旗舰基座，长程任务显著提升，可自主工作长达8小时，闭环交付工程级成果，整体表现对齐Claude Opus 4.6。 调用说明请查看： API调用文档",
      "autoModelUpdate": true
    }
  ]
};
